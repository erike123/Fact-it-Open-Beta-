class m{constructor(e,t){this.anchorElement=e,this.result=t,this.handleEscapeKey=i=>{i.key==="Escape"&&this.hide()},this.element=document.createElement("div"),this.shadowRoot=this.element.attachShadow({mode:"closed"}),this.element.style.position="fixed",this.element.style.zIndex="2147483647",this.boundHandleOutsideClick=this.handleOutsideClick.bind(this),document.body.appendChild(this.element)}show(){const e=this.anchorElement.getBoundingClientRect(),t=320,i=400;let s=e.bottom+8,o=e.right-t;const n=window.innerWidth,a=window.innerHeight;o<8&&(o=8),o+t>n-8&&(o=n-t-8),s+i>a-8&&(s=e.top-i-8,s<8&&(s=8)),this.element.style.top=`${s}px`,this.element.style.left=`${o}px`;const h={true:"#4CAF50",false:"#f44336",unknown:"#FFC107",no_claim:"#9E9E9E"},p={true:"Verified True",false:"Verified False",unknown:"Unverifiable",no_claim:"No Claims"};this.shadowRoot.innerHTML=`
      <style>
        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
        }

        .popup {
          width: 320px;
          max-height: 400px;
          background: white;
          border-radius: 12px;
          box-shadow: 0 8px 24px rgba(0, 0, 0, 0.25);
          overflow: hidden;
          font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
          font-size: 14px;
          line-height: 1.5;
          animation: slideIn 0.2s ease-out;
        }

        @keyframes slideIn {
          from {
            opacity: 0;
            transform: translateY(-8px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 16px;
          background: ${h[this.result.verdict]};
          color: white;
        }

        .verdict {
          font-weight: 600;
          font-size: 16px;
        }

        .close {
          background: none;
          border: none;
          font-size: 24px;
          cursor: pointer;
          padding: 0;
          width: 28px;
          height: 28px;
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          border-radius: 50%;
          transition: background 0.2s;
          line-height: 1;
        }

        .close:hover {
          background: rgba(255, 255, 255, 0.2);
        }

        .close:active {
          background: rgba(255, 255, 255, 0.3);
        }

        .content {
          padding: 16px;
          max-height: 320px;
          overflow-y: auto;
        }

        .confidence {
          margin-bottom: 16px;
        }

        .confidence-label {
          font-size: 12px;
          color: #666;
          margin-bottom: 6px;
          font-weight: 500;
        }

        .confidence-bar {
          width: 100%;
          height: 8px;
          background: #E0E0E0;
          border-radius: 4px;
          overflow: hidden;
        }

        .confidence-fill {
          height: 100%;
          background: ${h[this.result.verdict]};
          width: ${this.result.confidence}%;
          transition: width 0.5s ease-out;
          border-radius: 4px;
        }

        .confidence-text {
          font-size: 11px;
          color: #888;
          margin-top: 4px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 8px;
        }

        .provider-scores {
          display: flex;
          gap: 8px;
          align-items: center;
        }

        .provider-score {
          font-size: 11px;
          color: #888;
        }

        .provider-score-label {
          font-weight: 500;
        }

        .overall-score {
          font-weight: 600;
        }

        .explanation {
          margin-bottom: 16px;
          color: #333;
          line-height: 1.6;
        }

        .sources {
          margin-top: 16px;
          padding-top: 16px;
          border-top: 1px solid #E0E0E0;
        }

        .sources-title {
          font-weight: 600;
          margin-bottom: 10px;
          color: #333;
          font-size: 13px;
        }

        .source {
          margin-bottom: 10px;
        }

        .source:last-child {
          margin-bottom: 0;
        }

        .source a {
          color: #1976D2;
          text-decoration: none;
          font-size: 13px;
          line-height: 1.4;
          display: block;
          transition: color 0.2s;
        }

        .source a:hover {
          color: #1565C0;
          text-decoration: underline;
        }

        .source-domain {
          font-size: 11px;
          color: #999;
          margin-top: 2px;
        }

        .footer {
          padding: 12px 16px;
          background: #F5F5F5;
          border-top: 1px solid #E0E0E0;
          text-align: center;
          font-size: 11px;
          color: #666;
        }

        .footer a {
          color: #1976D2;
          text-decoration: none;
        }

        .footer a:hover {
          text-decoration: underline;
        }

        /* Scrollbar styling */
        .content::-webkit-scrollbar {
          width: 6px;
        }

        .content::-webkit-scrollbar-track {
          background: #F5F5F5;
        }

        .content::-webkit-scrollbar-thumb {
          background: #CCC;
          border-radius: 3px;
        }

        .content::-webkit-scrollbar-thumb:hover {
          background: #999;
        }
      </style>
      <div class="popup">
        <div class="header">
          <div class="verdict">${p[this.result.verdict]}</div>
          <button class="close" aria-label="Close" title="Close">×</button>
        </div>

        <div class="content">
          <div class="confidence">
            <div class="confidence-label">Overall Confidence</div>
            <div class="confidence-bar">
              <div class="confidence-fill"></div>
            </div>
            <div class="confidence-text">${this.renderProviderScores()}</div>
          </div>

          <div class="explanation">${this.escapeHtml(this.result.explanation)}</div>

          ${this.result.sources.length>0?`
            <div class="sources">
              <div class="sources-title">Sources</div>
              ${this.result.sources.map(r=>{const u=this.extractDomain(r.url);return`
                <div class="source">
                  <a href="${this.escapeHtml(r.url)}" target="_blank" rel="noopener noreferrer" title="${this.escapeHtml(r.title)}">
                    ${this.escapeHtml(this.truncate(r.title,60))}
                  </a>
                  <div class="source-domain">${this.escapeHtml(u)}</div>
                </div>
              `}).join("")}
            </div>
          `:""}
        </div>

        <div class="footer">
          Powered by <a href="https://github.com/erike123/Fact-it-Open-Beta-" target="_blank">Fact-It</a> • AI-generated verification
        </div>
      </div>
    `;const c=this.shadowRoot.querySelector(".popup");c==null||c.addEventListener("click",r=>{r.stopPropagation()});const l=this.shadowRoot.querySelector(".close");l==null||l.addEventListener("click",()=>this.hide()),setTimeout(()=>{document.addEventListener("click",this.boundHandleOutsideClick)},100),document.addEventListener("keydown",this.handleEscapeKey)}hide(){document.removeEventListener("click",this.boundHandleOutsideClick),document.removeEventListener("keydown",this.handleEscapeKey),this.element.remove()}handleOutsideClick(e){const t=e.target;!this.element.contains(t)&&!this.anchorElement.contains(t)&&this.hide()}escapeHtml(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}extractDomain(e){try{return new URL(e).hostname.replace(/^www\./,"")}catch{return e}}truncate(e,t){return e.length<=t?e:e.substring(0,t-3)+"..."}renderProviderScores(){if(!this.result.providerResults||this.result.providerResults.length===0)return`${this.result.confidence}% confident`;const e={openai:"OpenAI",anthropic:"Anthropic",perplexity:"Perplexity"};return`
      <div class="provider-scores">
        ${this.result.providerResults.map(i=>`<span class="provider-score"><span class="provider-score-label">${e[i.providerId]||i.providerName}:</span> ${i.confidence}%</span>`).join("")}
      </div>
      <span class="overall-score">Agg: ${this.result.confidence}%</span>
    `}}class f{constructor(e,t){this.parentElement=e,this.elementId=t,this.popup=null,this.element=document.createElement("div"),this.element.id=`fact-check-indicator-${this.elementId}`,this.shadowRoot=this.element.attachShadow({mode:"closed"}),this.element.style.position="absolute",this.element.style.top="-10px",this.element.style.right="-10px",this.element.style.zIndex="2147483647",this.showLoading(),this.attachToParent()}attachToParent(){window.getComputedStyle(this.parentElement).position==="static"&&(this.parentElement.style.position="relative"),this.parentElement.appendChild(this.element)}showLoading(){this.shadowRoot.innerHTML=`
      <style>
        * {
          box-sizing: border-box;
        }

        .indicator {
          width: 28px;
          height: 28px;
          border-radius: 50%;
          background: #FFC107;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
          animation: pulse 1.5s infinite;
          transition: transform 0.2s ease;
          font-family: system-ui, -apple-system, sans-serif;
        }

        .indicator:hover {
          transform: scale(1.1);
        }

        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.6; }
        }

        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }

        .spinner {
          width: 14px;
          height: 14px;
          border: 2px solid white;
          border-top-color: transparent;
          border-radius: 50%;
          animation: spin 1s linear infinite;
        }
      </style>
      <div class="indicator" aria-label="Fact check in progress" role="status">
        <div class="spinner"></div>
      </div>
    `}showResult(e){const t={true:"#4CAF50",false:"#f44336",unknown:"#FFC107",no_claim:"#9E9E9E"},i={true:"✓",false:"✗",unknown:"?",no_claim:"○"},s={true:"Fact check result: verified true",false:"Fact check result: verified false",unknown:"Fact check result: unverifiable",no_claim:"No factual claims detected"};if(this.shadowRoot.innerHTML=`
      <style>
        * {
          box-sizing: border-box;
        }

        .indicator {
          width: 28px;
          height: 28px;
          border-radius: 50%;
          background: ${t[e.verdict]};
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: bold;
          font-size: 16px;
          cursor: pointer;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
          transition: transform 0.2s ease, box-shadow 0.2s ease;
          font-family: system-ui, -apple-system, sans-serif;
          user-select: none;
        }

        .indicator:hover {
          transform: scale(1.15);
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        }

        .indicator:active {
          transform: scale(1.05);
        }

        @keyframes scaleIn {
          from {
            transform: scale(0);
            opacity: 0;
          }
          to {
            transform: scale(1);
            opacity: 1;
          }
        }

        .indicator.animate {
          animation: scaleIn 0.3s ease-out;
        }
      </style>
      <div class="indicator animate"
           aria-label="${s[e.verdict]}"
           tabindex="0"
           role="button">
        ${i[e.verdict]}
      </div>
    `,e.verdict!=="no_claim"){const o=this.shadowRoot.querySelector(".indicator");o==null||o.addEventListener("click",n=>{n.stopPropagation(),this.showPopup(e)}),o==null||o.addEventListener("keydown",n=>{const a=n;(a.key==="Enter"||a.key===" ")&&(n.preventDefault(),n.stopPropagation(),this.showPopup(e))})}}showPopup(e){this.popup&&this.popup.hide(),this.popup=new m(this.element,e),this.popup.show()}remove(){this.popup&&this.popup.hide(),this.element.remove()}}class b{constructor(e,t){this.elementId=t,this.onCheckCallback=null,this.parentElement=e,this.element=document.createElement("div"),this.element.id=`fact-check-button-${this.elementId}`,this.shadowRoot=this.element.attachShadow({mode:"closed"}),this.element.style.position="absolute",this.element.style.top="-10px",this.element.style.right="-10px",this.element.style.zIndex="2147483647",this.showButton(),this.attachToParent()}attachToParent(){window.getComputedStyle(this.parentElement).position==="static"&&(this.parentElement.style.position="relative"),this.parentElement.appendChild(this.element)}onCheck(e){this.onCheckCallback=e}showButton(){this.shadowRoot.innerHTML=`
      <style>
        * {
          box-sizing: border-box;
        }

        .check-button {
          width: 28px;
          height: 28px;
          border-radius: 50%;
          background: #1976D2;
          color: white;
          border: none;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: bold;
          font-size: 16px;
          cursor: pointer;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
          transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
          font-family: system-ui, -apple-system, sans-serif;
          user-select: none;
        }

        .check-button:hover {
          background: #1565C0;
          transform: scale(1.15);
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        }

        .check-button:active {
          transform: scale(1.05);
        }

        @keyframes scaleIn {
          from {
            transform: scale(0);
            opacity: 0;
          }
          to {
            transform: scale(1);
            opacity: 1;
          }
        }

        .check-button.animate {
          animation: scaleIn 0.3s ease-out;
        }
      </style>
      <button class="check-button animate"
              aria-label="Click to fact-check this post"
              tabindex="0"
              role="button">
        ▶
      </button>
    `;const e=this.shadowRoot.querySelector(".check-button");e==null||e.addEventListener("click",t=>{t.stopPropagation(),this.handleClick()}),e==null||e.addEventListener("keydown",t=>{const i=t;(i.key==="Enter"||i.key===" ")&&(t.preventDefault(),t.stopPropagation(),this.handleClick())})}handleClick(){this.showLoading(),this.onCheckCallback&&this.onCheckCallback()}showLoading(){this.shadowRoot.innerHTML=`
      <style>
        * {
          box-sizing: border-box;
        }

        .indicator {
          width: 28px;
          height: 28px;
          border-radius: 50%;
          background: #FFC107;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: wait;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
          animation: pulse 1.5s infinite;
          font-family: system-ui, -apple-system, sans-serif;
        }

        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.6; }
        }

        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }

        .spinner {
          width: 14px;
          height: 14px;
          border: 2px solid white;
          border-top-color: transparent;
          border-radius: 50%;
          animation: spin 1s linear infinite;
        }
      </style>
      <div class="indicator" aria-label="Fact check in progress" role="status">
        <div class="spinner"></div>
      </div>
    `}remove(){this.element.remove()}}export{b as C,f as F};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hlY2stYnV0dG9uLUIyQnNMbVFVLmpzIiwic291cmNlcyI6WyIuLi8uLi9zcmMvY29udGVudC91aS9wb3B1cC50cyIsIi4uLy4uL3NyYy9jb250ZW50L3VpL2luZGljYXRvci50cyIsIi4uLy4uL3NyYy9jb250ZW50L3VpL2NoZWNrLWJ1dHRvbi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogRmFjdCBDaGVjayBQb3B1cCBDb21wb25lbnRcclxuICogU2hvd3MgZGV0YWlsZWQgZXhwbGFuYXRpb24sIGNvbmZpZGVuY2Ugc2NvcmUsIGFuZCBzb3VyY2VzXHJcbiAqL1xyXG5cclxuaW1wb3J0IHsgVmVyZGljdCB9IGZyb20gJ0Avc2hhcmVkL3R5cGVzJztcclxuXHJcbmV4cG9ydCBjbGFzcyBGYWN0Q2hlY2tQb3B1cCB7XHJcbiAgcHJpdmF0ZSBlbGVtZW50OiBIVE1MRGl2RWxlbWVudDtcclxuICBwcml2YXRlIHNoYWRvd1Jvb3Q6IFNoYWRvd1Jvb3Q7XHJcbiAgcHJpdmF0ZSBib3VuZEhhbmRsZU91dHNpZGVDbGljazogKGU6IE1vdXNlRXZlbnQpID0+IHZvaWQ7XHJcblxyXG4gIGNvbnN0cnVjdG9yKFxyXG4gICAgcHJpdmF0ZSBhbmNob3JFbGVtZW50OiBIVE1MRWxlbWVudCxcclxuICAgIHByaXZhdGUgcmVzdWx0OiB7XHJcbiAgICAgIHZlcmRpY3Q6IFZlcmRpY3Q7XHJcbiAgICAgIGNvbmZpZGVuY2U6IG51bWJlcjtcclxuICAgICAgZXhwbGFuYXRpb246IHN0cmluZztcclxuICAgICAgc291cmNlczogQXJyYXk8eyB0aXRsZTogc3RyaW5nOyB1cmw6IHN0cmluZyB9PjtcclxuICAgICAgcHJvdmlkZXJSZXN1bHRzPzogQXJyYXk8e1xyXG4gICAgICAgIHByb3ZpZGVySWQ6IHN0cmluZztcclxuICAgICAgICBwcm92aWRlck5hbWU6IHN0cmluZztcclxuICAgICAgICB2ZXJkaWN0OiAndHJ1ZScgfCAnZmFsc2UnIHwgJ3Vua25vd24nO1xyXG4gICAgICAgIGNvbmZpZGVuY2U6IG51bWJlcjtcclxuICAgICAgICBleHBsYW5hdGlvbjogc3RyaW5nO1xyXG4gICAgICB9PjtcclxuICAgICAgY29uc2Vuc3VzPzoge1xyXG4gICAgICAgIHRvdGFsOiBudW1iZXI7XHJcbiAgICAgICAgYWdyZWVpbmc6IG51bWJlcjtcclxuICAgICAgfTtcclxuICAgIH1cclxuICApIHtcclxuICAgIHRoaXMuZWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gICAgdGhpcy5zaGFkb3dSb290ID0gdGhpcy5lbGVtZW50LmF0dGFjaFNoYWRvdyh7IG1vZGU6ICdjbG9zZWQnIH0pO1xyXG5cclxuICAgIHRoaXMuZWxlbWVudC5zdHlsZS5wb3NpdGlvbiA9ICdmaXhlZCc7XHJcbiAgICB0aGlzLmVsZW1lbnQuc3R5bGUuekluZGV4ID0gJzIxNDc0ODM2NDcnO1xyXG5cclxuICAgIHRoaXMuYm91bmRIYW5kbGVPdXRzaWRlQ2xpY2sgPSB0aGlzLmhhbmRsZU91dHNpZGVDbGljay5iaW5kKHRoaXMpO1xyXG5cclxuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQodGhpcy5lbGVtZW50KTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFNob3cgdGhlIHBvcHVwXHJcbiAgICovXHJcbiAgc2hvdygpOiB2b2lkIHtcclxuICAgIGNvbnN0IHJlY3QgPSB0aGlzLmFuY2hvckVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XHJcblxyXG4gICAgLy8gUG9zaXRpb24gYmVsb3cgYW5kIHRvIHRoZSBsZWZ0IG9mIGluZGljYXRvciAoaW5kaWNhdG9yIGlzIGluIHRvcC1yaWdodCBjb3JuZXIpXHJcbiAgICBjb25zdCBwb3B1cFdpZHRoID0gMzIwO1xyXG4gICAgY29uc3QgcG9wdXBIZWlnaHQgPSA0MDA7XHJcbiAgICBsZXQgdG9wID0gcmVjdC5ib3R0b20gKyA4OyAvLyBQb3NpdGlvbiBiZWxvdyBpbmRpY2F0b3JcclxuICAgIGxldCBsZWZ0ID0gcmVjdC5yaWdodCAtIHBvcHVwV2lkdGg7IC8vIEFsaWduIHJpZ2h0IGVkZ2Ugb2YgcG9wdXAgd2l0aCBpbmRpY2F0b3JcclxuXHJcbiAgICAvLyBFbnN1cmUgcG9wdXAgc3RheXMgd2l0aGluIHZpZXdwb3J0XHJcbiAgICBjb25zdCB2aWV3cG9ydFdpZHRoID0gd2luZG93LmlubmVyV2lkdGg7XHJcbiAgICBjb25zdCB2aWV3cG9ydEhlaWdodCA9IHdpbmRvdy5pbm5lckhlaWdodDtcclxuXHJcbiAgICAvLyBBZGp1c3QgaG9yaXpvbnRhbCBwb3NpdGlvbiBpZiBuZWVkZWRcclxuICAgIGlmIChsZWZ0IDwgOCkge1xyXG4gICAgICBsZWZ0ID0gODsgLy8gTWluIGxlZnQgcGFkZGluZ1xyXG4gICAgfVxyXG4gICAgaWYgKGxlZnQgKyBwb3B1cFdpZHRoID4gdmlld3BvcnRXaWR0aCAtIDgpIHtcclxuICAgICAgbGVmdCA9IHZpZXdwb3J0V2lkdGggLSBwb3B1cFdpZHRoIC0gODsgLy8gTWF4IHJpZ2h0IHBhZGRpbmdcclxuICAgIH1cclxuXHJcbiAgICAvLyBJZiBwb3B1cCB3b3VsZCBnbyBiZWxvdyB2aWV3cG9ydCwgcG9zaXRpb24gYWJvdmUgaW5kaWNhdG9yIGluc3RlYWRcclxuICAgIGlmICh0b3AgKyBwb3B1cEhlaWdodCA+IHZpZXdwb3J0SGVpZ2h0IC0gOCkge1xyXG4gICAgICB0b3AgPSByZWN0LnRvcCAtIHBvcHVwSGVpZ2h0IC0gODtcclxuICAgICAgaWYgKHRvcCA8IDgpIHtcclxuICAgICAgICB0b3AgPSA4OyAvLyBGYWxsYmFjayB0byB0b3Agb2Ygdmlld3BvcnRcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHRoaXMuZWxlbWVudC5zdHlsZS50b3AgPSBgJHt0b3B9cHhgO1xyXG4gICAgdGhpcy5lbGVtZW50LnN0eWxlLmxlZnQgPSBgJHtsZWZ0fXB4YDtcclxuXHJcbiAgICBjb25zdCB2ZXJkaWN0Q29sb3JzOiBSZWNvcmQ8VmVyZGljdCwgc3RyaW5nPiA9IHtcclxuICAgICAgdHJ1ZTogJyM0Q0FGNTAnLFxyXG4gICAgICBmYWxzZTogJyNmNDQzMzYnLFxyXG4gICAgICB1bmtub3duOiAnI0ZGQzEwNycsXHJcbiAgICAgIG5vX2NsYWltOiAnIzlFOUU5RScsXHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IHZlcmRpY3RMYWJlbHM6IFJlY29yZDxWZXJkaWN0LCBzdHJpbmc+ID0ge1xyXG4gICAgICB0cnVlOiAnVmVyaWZpZWQgVHJ1ZScsXHJcbiAgICAgIGZhbHNlOiAnVmVyaWZpZWQgRmFsc2UnLFxyXG4gICAgICB1bmtub3duOiAnVW52ZXJpZmlhYmxlJyxcclxuICAgICAgbm9fY2xhaW06ICdObyBDbGFpbXMnLFxyXG4gICAgfTtcclxuXHJcbiAgICB0aGlzLnNoYWRvd1Jvb3QuaW5uZXJIVE1MID0gYFxyXG4gICAgICA8c3R5bGU+XHJcbiAgICAgICAgKiB7XHJcbiAgICAgICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5wb3B1cCB7XHJcbiAgICAgICAgICB3aWR0aDogMzIwcHg7XHJcbiAgICAgICAgICBtYXgtaGVpZ2h0OiA0MDBweDtcclxuICAgICAgICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAgICAgICAgYm9yZGVyLXJhZGl1czogMTJweDtcclxuICAgICAgICAgIGJveC1zaGFkb3c6IDAgOHB4IDI0cHggcmdiYSgwLCAwLCAwLCAwLjI1KTtcclxuICAgICAgICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICAgICAgICBmb250LWZhbWlseTogc3lzdGVtLXVpLCAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsICdTZWdvZSBVSScsIHNhbnMtc2VyaWY7XHJcbiAgICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgICAgICBsaW5lLWhlaWdodDogMS41O1xyXG4gICAgICAgICAgYW5pbWF0aW9uOiBzbGlkZUluIDAuMnMgZWFzZS1vdXQ7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBAa2V5ZnJhbWVzIHNsaWRlSW4ge1xyXG4gICAgICAgICAgZnJvbSB7XHJcbiAgICAgICAgICAgIG9wYWNpdHk6IDA7XHJcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtOHB4KTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHRvIHtcclxuICAgICAgICAgICAgb3BhY2l0eTogMTtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmhlYWRlciB7XHJcbiAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICAgIHBhZGRpbmc6IDE2cHg7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kOiAke3ZlcmRpY3RDb2xvcnNbdGhpcy5yZXN1bHQudmVyZGljdF19O1xyXG4gICAgICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLnZlcmRpY3Qge1xyXG4gICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5jbG9zZSB7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kOiBub25lO1xyXG4gICAgICAgICAgYm9yZGVyOiBub25lO1xyXG4gICAgICAgICAgZm9udC1zaXplOiAyNHB4O1xyXG4gICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICAgIHdpZHRoOiAyOHB4O1xyXG4gICAgICAgICAgaGVpZ2h0OiAyOHB4O1xyXG4gICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICAgIHRyYW5zaXRpb246IGJhY2tncm91bmQgMC4ycztcclxuICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmNsb3NlOmhvdmVyIHtcclxuICAgICAgICAgIGJhY2tncm91bmQ6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC4yKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5jbG9zZTphY3RpdmUge1xyXG4gICAgICAgICAgYmFja2dyb3VuZDogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjMpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmNvbnRlbnQge1xyXG4gICAgICAgICAgcGFkZGluZzogMTZweDtcclxuICAgICAgICAgIG1heC1oZWlnaHQ6IDMyMHB4O1xyXG4gICAgICAgICAgb3ZlcmZsb3cteTogYXV0bztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5jb25maWRlbmNlIHtcclxuICAgICAgICAgIG1hcmdpbi1ib3R0b206IDE2cHg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuY29uZmlkZW5jZS1sYWJlbCB7XHJcbiAgICAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICAgICAgICBjb2xvcjogIzY2NjtcclxuICAgICAgICAgIG1hcmdpbi1ib3R0b206IDZweDtcclxuICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuY29uZmlkZW5jZS1iYXIge1xyXG4gICAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgICBoZWlnaHQ6IDhweDtcclxuICAgICAgICAgIGJhY2tncm91bmQ6ICNFMEUwRTA7XHJcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICAgICAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmNvbmZpZGVuY2UtZmlsbCB7XHJcbiAgICAgICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kOiAke3ZlcmRpY3RDb2xvcnNbdGhpcy5yZXN1bHQudmVyZGljdF19O1xyXG4gICAgICAgICAgd2lkdGg6ICR7dGhpcy5yZXN1bHQuY29uZmlkZW5jZX0lO1xyXG4gICAgICAgICAgdHJhbnNpdGlvbjogd2lkdGggMC41cyBlYXNlLW91dDtcclxuICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5jb25maWRlbmNlLXRleHQge1xyXG4gICAgICAgICAgZm9udC1zaXplOiAxMXB4O1xyXG4gICAgICAgICAgY29sb3I6ICM4ODg7XHJcbiAgICAgICAgICBtYXJnaW4tdG9wOiA0cHg7XHJcbiAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICAgIGdhcDogOHB4O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLnByb3ZpZGVyLXNjb3JlcyB7XHJcbiAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgZ2FwOiA4cHg7XHJcbiAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLnByb3ZpZGVyLXNjb3JlIHtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMTFweDtcclxuICAgICAgICAgIGNvbG9yOiAjODg4O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLnByb3ZpZGVyLXNjb3JlLWxhYmVsIHtcclxuICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAub3ZlcmFsbC1zY29yZSB7XHJcbiAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmV4cGxhbmF0aW9uIHtcclxuICAgICAgICAgIG1hcmdpbi1ib3R0b206IDE2cHg7XHJcbiAgICAgICAgICBjb2xvcjogIzMzMztcclxuICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxLjY7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuc291cmNlcyB7XHJcbiAgICAgICAgICBtYXJnaW4tdG9wOiAxNnB4O1xyXG4gICAgICAgICAgcGFkZGluZy10b3A6IDE2cHg7XHJcbiAgICAgICAgICBib3JkZXItdG9wOiAxcHggc29saWQgI0UwRTBFMDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5zb3VyY2VzLXRpdGxlIHtcclxuICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG4gICAgICAgICAgY29sb3I6ICMzMzM7XHJcbiAgICAgICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuc291cmNlIHtcclxuICAgICAgICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuc291cmNlOmxhc3QtY2hpbGQge1xyXG4gICAgICAgICAgbWFyZ2luLWJvdHRvbTogMDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5zb3VyY2UgYSB7XHJcbiAgICAgICAgICBjb2xvcjogIzE5NzZEMjtcclxuICAgICAgICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxLjQ7XHJcbiAgICAgICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgICAgICAgIHRyYW5zaXRpb246IGNvbG9yIDAuMnM7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuc291cmNlIGE6aG92ZXIge1xyXG4gICAgICAgICAgY29sb3I6ICMxNTY1QzA7XHJcbiAgICAgICAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5zb3VyY2UtZG9tYWluIHtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMTFweDtcclxuICAgICAgICAgIGNvbG9yOiAjOTk5O1xyXG4gICAgICAgICAgbWFyZ2luLXRvcDogMnB4O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmZvb3RlciB7XHJcbiAgICAgICAgICBwYWRkaW5nOiAxMnB4IDE2cHg7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kOiAjRjVGNUY1O1xyXG4gICAgICAgICAgYm9yZGVyLXRvcDogMXB4IHNvbGlkICNFMEUwRTA7XHJcbiAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICBmb250LXNpemU6IDExcHg7XHJcbiAgICAgICAgICBjb2xvcjogIzY2NjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5mb290ZXIgYSB7XHJcbiAgICAgICAgICBjb2xvcjogIzE5NzZEMjtcclxuICAgICAgICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5mb290ZXIgYTpob3ZlciB7XHJcbiAgICAgICAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8qIFNjcm9sbGJhciBzdHlsaW5nICovXHJcbiAgICAgICAgLmNvbnRlbnQ6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcclxuICAgICAgICAgIHdpZHRoOiA2cHg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuY29udGVudDo6LXdlYmtpdC1zY3JvbGxiYXItdHJhY2sge1xyXG4gICAgICAgICAgYmFja2dyb3VuZDogI0Y1RjVGNTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5jb250ZW50Ojotd2Via2l0LXNjcm9sbGJhci10aHVtYiB7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kOiAjQ0NDO1xyXG4gICAgICAgICAgYm9yZGVyLXJhZGl1czogM3B4O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmNvbnRlbnQ6Oi13ZWJraXQtc2Nyb2xsYmFyLXRodW1iOmhvdmVyIHtcclxuICAgICAgICAgIGJhY2tncm91bmQ6ICM5OTk7XHJcbiAgICAgICAgfVxyXG4gICAgICA8L3N0eWxlPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwicG9wdXBcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwiaGVhZGVyXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwidmVyZGljdFwiPiR7dmVyZGljdExhYmVsc1t0aGlzLnJlc3VsdC52ZXJkaWN0XX08L2Rpdj5cclxuICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJjbG9zZVwiIGFyaWEtbGFiZWw9XCJDbG9zZVwiIHRpdGxlPVwiQ2xvc2VcIj7DlzwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwiY29udGVudFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImNvbmZpZGVuY2VcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbmZpZGVuY2UtbGFiZWxcIj5PdmVyYWxsIENvbmZpZGVuY2U8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbmZpZGVuY2UtYmFyXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbmZpZGVuY2UtZmlsbFwiPjwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbmZpZGVuY2UtdGV4dFwiPiR7dGhpcy5yZW5kZXJQcm92aWRlclNjb3JlcygpfTwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImV4cGxhbmF0aW9uXCI+JHt0aGlzLmVzY2FwZUh0bWwodGhpcy5yZXN1bHQuZXhwbGFuYXRpb24pfTwvZGl2PlxyXG5cclxuICAgICAgICAgICR7XHJcbiAgICAgICAgICAgIHRoaXMucmVzdWx0LnNvdXJjZXMubGVuZ3RoID4gMFxyXG4gICAgICAgICAgICAgID8gYFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwic291cmNlc1wiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzb3VyY2VzLXRpdGxlXCI+U291cmNlczwvZGl2PlxyXG4gICAgICAgICAgICAgICR7dGhpcy5yZXN1bHQuc291cmNlc1xyXG4gICAgICAgICAgICAgICAgLm1hcCgoc291cmNlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGRvbWFpbiA9IHRoaXMuZXh0cmFjdERvbWFpbihzb3VyY2UudXJsKTtcclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIGBcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzb3VyY2VcIj5cclxuICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cIiR7dGhpcy5lc2NhcGVIdG1sKHNvdXJjZS51cmwpfVwiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIiB0aXRsZT1cIiR7dGhpcy5lc2NhcGVIdG1sKHNvdXJjZS50aXRsZSl9XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgJHt0aGlzLmVzY2FwZUh0bWwodGhpcy50cnVuY2F0ZShzb3VyY2UudGl0bGUsIDYwKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNvdXJjZS1kb21haW5cIj4ke3RoaXMuZXNjYXBlSHRtbChkb21haW4pfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgYDtcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAuam9pbignJyl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgYFxyXG4gICAgICAgICAgICAgIDogJydcclxuICAgICAgICAgIH1cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImZvb3RlclwiPlxyXG4gICAgICAgICAgUG93ZXJlZCBieSA8YSBocmVmPVwiaHR0cHM6Ly9naXRodWIuY29tL2VyaWtlMTIzL0ZhY3QtaXQtT3Blbi1CZXRhLVwiIHRhcmdldD1cIl9ibGFua1wiPkZhY3QtSXQ8L2E+IOKAoiBBSS1nZW5lcmF0ZWQgdmVyaWZpY2F0aW9uXHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgYDtcclxuXHJcbiAgICAvLyBQcmV2ZW50IGNsaWNrcyBpbnNpZGUgcG9wdXAgZnJvbSBidWJibGluZyB0byB1bmRlcmx5aW5nIHBhZ2VcclxuICAgIGNvbnN0IHBvcHVwRWxlbWVudCA9IHRoaXMuc2hhZG93Um9vdC5xdWVyeVNlbGVjdG9yKCcucG9wdXAnKTtcclxuICAgIHBvcHVwRWxlbWVudD8uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZTogRXZlbnQpID0+IHtcclxuICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTsgLy8gUHJldmVudCBjbGlja3MgZnJvbSBidWJibGluZyB0aHJvdWdoIHRvIHBvc3RcclxuICAgIH0pO1xyXG5cclxuICAgIC8vIENsb3NlIGJ1dHRvbiBoYW5kbGVyXHJcbiAgICBjb25zdCBjbG9zZUJ0biA9IHRoaXMuc2hhZG93Um9vdC5xdWVyeVNlbGVjdG9yKCcuY2xvc2UnKTtcclxuICAgIGNsb3NlQnRuPy5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHRoaXMuaGlkZSgpKTtcclxuXHJcbiAgICAvLyBDbG9zZSBvbiBjbGljayBvdXRzaWRlICh3aXRoIHNtYWxsIGRlbGF5IHRvIGF2b2lkIGltbWVkaWF0ZSBjbG9zZSlcclxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIHRoaXMuYm91bmRIYW5kbGVPdXRzaWRlQ2xpY2spO1xyXG4gICAgfSwgMTAwKTtcclxuXHJcbiAgICAvLyBDbG9zZSBvbiBFc2NhcGUga2V5XHJcbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgdGhpcy5oYW5kbGVFc2NhcGVLZXkpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogSGlkZSB0aGUgcG9wdXBcclxuICAgKi9cclxuICBoaWRlKCk6IHZvaWQge1xyXG4gICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignY2xpY2snLCB0aGlzLmJvdW5kSGFuZGxlT3V0c2lkZUNsaWNrKTtcclxuICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCB0aGlzLmhhbmRsZUVzY2FwZUtleSk7XHJcbiAgICB0aGlzLmVsZW1lbnQucmVtb3ZlKCk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBIYW5kbGUgY2xpY2tzIG91dHNpZGUgdGhlIHBvcHVwXHJcbiAgICovXHJcbiAgcHJpdmF0ZSBoYW5kbGVPdXRzaWRlQ2xpY2soZTogTW91c2VFdmVudCk6IHZvaWQge1xyXG4gICAgY29uc3QgdGFyZ2V0ID0gZS50YXJnZXQgYXMgTm9kZTtcclxuICAgIGlmIChcclxuICAgICAgIXRoaXMuZWxlbWVudC5jb250YWlucyh0YXJnZXQpICYmXHJcbiAgICAgICF0aGlzLmFuY2hvckVsZW1lbnQuY29udGFpbnModGFyZ2V0KVxyXG4gICAgKSB7XHJcbiAgICAgIHRoaXMuaGlkZSgpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogSGFuZGxlIEVzY2FwZSBrZXkgdG8gY2xvc2UgcG9wdXBcclxuICAgKi9cclxuICBwcml2YXRlIGhhbmRsZUVzY2FwZUtleSA9IChlOiBLZXlib2FyZEV2ZW50KTogdm9pZCA9PiB7XHJcbiAgICBpZiAoZS5rZXkgPT09ICdFc2NhcGUnKSB7XHJcbiAgICAgIHRoaXMuaGlkZSgpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8qKlxyXG4gICAqIEVzY2FwZSBIVE1MIHRvIHByZXZlbnQgWFNTXHJcbiAgICovXHJcbiAgcHJpdmF0ZSBlc2NhcGVIdG1sKHVuc2FmZTogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgIHJldHVybiB1bnNhZmVcclxuICAgICAgLnJlcGxhY2UoLyYvZywgJyZhbXA7JylcclxuICAgICAgLnJlcGxhY2UoLzwvZywgJyZsdDsnKVxyXG4gICAgICAucmVwbGFjZSgvPi9nLCAnJmd0OycpXHJcbiAgICAgIC5yZXBsYWNlKC9cIi9nLCAnJnF1b3Q7JylcclxuICAgICAgLnJlcGxhY2UoLycvZywgJyYjMDM5OycpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogRXh0cmFjdCBkb21haW4gZnJvbSBVUkxcclxuICAgKi9cclxuICBwcml2YXRlIGV4dHJhY3REb21haW4odXJsOiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgdXJsT2JqID0gbmV3IFVSTCh1cmwpO1xyXG4gICAgICByZXR1cm4gdXJsT2JqLmhvc3RuYW1lLnJlcGxhY2UoL153d3dcXC4vLCAnJyk7XHJcbiAgICB9IGNhdGNoIHtcclxuICAgICAgcmV0dXJuIHVybDtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFRydW5jYXRlIHRleHQgdG8gbWF4IGxlbmd0aFxyXG4gICAqL1xyXG4gIHByaXZhdGUgdHJ1bmNhdGUodGV4dDogc3RyaW5nLCBtYXhMZW5ndGg6IG51bWJlcik6IHN0cmluZyB7XHJcbiAgICBpZiAodGV4dC5sZW5ndGggPD0gbWF4TGVuZ3RoKSByZXR1cm4gdGV4dDtcclxuICAgIHJldHVybiB0ZXh0LnN1YnN0cmluZygwLCBtYXhMZW5ndGggLSAzKSArICcuLi4nO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUmVuZGVyIHByb3ZpZGVyIHNjb3JlcyBpbmxpbmUgYmVsb3cgY29uZmlkZW5jZSBiYXJcclxuICAgKi9cclxuICBwcml2YXRlIHJlbmRlclByb3ZpZGVyU2NvcmVzKCk6IHN0cmluZyB7XHJcbiAgICBpZiAoIXRoaXMucmVzdWx0LnByb3ZpZGVyUmVzdWx0cyB8fCB0aGlzLnJlc3VsdC5wcm92aWRlclJlc3VsdHMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgIHJldHVybiBgJHt0aGlzLnJlc3VsdC5jb25maWRlbmNlfSUgY29uZmlkZW50YDtcclxuICAgIH1cclxuXHJcbiAgICAvLyBNYXAgcHJvdmlkZXIgSURzIHRvIHNob3J0IG5hbWVzXHJcbiAgICBjb25zdCBwcm92aWRlclNob3J0TmFtZXM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XHJcbiAgICAgIG9wZW5haTogJ09wZW5BSScsXHJcbiAgICAgIGFudGhyb3BpYzogJ0FudGhyb3BpYycsXHJcbiAgICAgIHBlcnBsZXhpdHk6ICdQZXJwbGV4aXR5JyxcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgcHJvdmlkZXJTY29yZXMgPSB0aGlzLnJlc3VsdC5wcm92aWRlclJlc3VsdHNcclxuICAgICAgLm1hcCgocHJvdmlkZXIpID0+IHtcclxuICAgICAgICBjb25zdCBzaG9ydE5hbWUgPSBwcm92aWRlclNob3J0TmFtZXNbcHJvdmlkZXIucHJvdmlkZXJJZF0gfHwgcHJvdmlkZXIucHJvdmlkZXJOYW1lO1xyXG4gICAgICAgIHJldHVybiBgPHNwYW4gY2xhc3M9XCJwcm92aWRlci1zY29yZVwiPjxzcGFuIGNsYXNzPVwicHJvdmlkZXItc2NvcmUtbGFiZWxcIj4ke3Nob3J0TmFtZX06PC9zcGFuPiAke3Byb3ZpZGVyLmNvbmZpZGVuY2V9JTwvc3Bhbj5gO1xyXG4gICAgICB9KVxyXG4gICAgICAuam9pbignJyk7XHJcblxyXG4gICAgcmV0dXJuIGBcclxuICAgICAgPGRpdiBjbGFzcz1cInByb3ZpZGVyLXNjb3Jlc1wiPlxyXG4gICAgICAgICR7cHJvdmlkZXJTY29yZXN9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8c3BhbiBjbGFzcz1cIm92ZXJhbGwtc2NvcmVcIj5BZ2c6ICR7dGhpcy5yZXN1bHQuY29uZmlkZW5jZX0lPC9zcGFuPlxyXG4gICAgYDtcclxuICB9XHJcbn1cclxuIiwiLyoqXHJcbiAqIEZhY3QgQ2hlY2sgSW5kaWNhdG9yIENvbXBvbmVudFxyXG4gKiBWaXN1YWwgaW5kaWNhdG9yIHNob3dpbmcgZmFjdC1jaGVjayB2ZXJkaWN0IHdpdGggU2hhZG93IERPTSBmb3Igc3R5bGUgaXNvbGF0aW9uXHJcbiAqL1xyXG5cclxuaW1wb3J0IHsgVmVyZGljdCB9IGZyb20gJ0Avc2hhcmVkL3R5cGVzJztcclxuaW1wb3J0IHsgRmFjdENoZWNrUG9wdXAgfSBmcm9tICcuL3BvcHVwJztcclxuXHJcbmV4cG9ydCBjbGFzcyBGYWN0Q2hlY2tJbmRpY2F0b3Ige1xyXG4gIHByaXZhdGUgZWxlbWVudDogSFRNTERpdkVsZW1lbnQ7XHJcbiAgcHJpdmF0ZSBzaGFkb3dSb290OiBTaGFkb3dSb290O1xyXG4gIHByaXZhdGUgcG9wdXA6IEZhY3RDaGVja1BvcHVwIHwgbnVsbCA9IG51bGw7XHJcblxyXG4gIGNvbnN0cnVjdG9yKFxyXG4gICAgcHJpdmF0ZSBwYXJlbnRFbGVtZW50OiBFbGVtZW50LFxyXG4gICAgcHJpdmF0ZSBlbGVtZW50SWQ6IHN0cmluZ1xyXG4gICkge1xyXG4gICAgdGhpcy5lbGVtZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XHJcbiAgICB0aGlzLmVsZW1lbnQuaWQgPSBgZmFjdC1jaGVjay1pbmRpY2F0b3ItJHt0aGlzLmVsZW1lbnRJZH1gO1xyXG5cclxuICAgIC8vIFVzZSBTaGFkb3cgRE9NIGZvciBzdHlsZSBpc29sYXRpb25cclxuICAgIHRoaXMuc2hhZG93Um9vdCA9IHRoaXMuZWxlbWVudC5hdHRhY2hTaGFkb3coeyBtb2RlOiAnY2xvc2VkJyB9KTtcclxuXHJcbiAgICAvLyBQb3NpdGlvbiBhYnNvbHV0ZWx5IHNsaWdodGx5IG91dHNpZGUgdG9wLXJpZ2h0IGNvcm5lciBvZiBjYXJkXHJcbiAgICB0aGlzLmVsZW1lbnQuc3R5bGUucG9zaXRpb24gPSAnYWJzb2x1dGUnO1xyXG4gICAgdGhpcy5lbGVtZW50LnN0eWxlLnRvcCA9ICctMTBweCc7XHJcbiAgICB0aGlzLmVsZW1lbnQuc3R5bGUucmlnaHQgPSAnLTEwcHgnO1xyXG4gICAgdGhpcy5lbGVtZW50LnN0eWxlLnpJbmRleCA9ICcyMTQ3NDgzNjQ3JzsgLy8gTWF4aW11bSB6LWluZGV4XHJcblxyXG4gICAgdGhpcy5zaG93TG9hZGluZygpO1xyXG4gICAgdGhpcy5hdHRhY2hUb1BhcmVudCgpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogQXR0YWNoIGluZGljYXRvciB0byBwYXJlbnQgZWxlbWVudFxyXG4gICAqL1xyXG4gIHByaXZhdGUgYXR0YWNoVG9QYXJlbnQoKTogdm9pZCB7XHJcbiAgICAvLyBNYWtlIHBhcmVudCByZWxhdGl2ZWx5IHBvc2l0aW9uZWQgaWYgbmVlZGVkXHJcbiAgICBjb25zdCBwYXJlbnRTdHlsZSA9IHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKHRoaXMucGFyZW50RWxlbWVudCk7XHJcbiAgICBpZiAocGFyZW50U3R5bGUucG9zaXRpb24gPT09ICdzdGF0aWMnKSB7XHJcbiAgICAgICh0aGlzLnBhcmVudEVsZW1lbnQgYXMgSFRNTEVsZW1lbnQpLnN0eWxlLnBvc2l0aW9uID0gJ3JlbGF0aXZlJztcclxuICAgIH1cclxuXHJcbiAgICB0aGlzLnBhcmVudEVsZW1lbnQuYXBwZW5kQ2hpbGQodGhpcy5lbGVtZW50KTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFNob3cgbG9hZGluZyBzdGF0ZSAoc3Bpbm5pbmcgaW5kaWNhdG9yKVxyXG4gICAqL1xyXG4gIHNob3dMb2FkaW5nKCk6IHZvaWQge1xyXG4gICAgdGhpcy5zaGFkb3dSb290LmlubmVySFRNTCA9IGBcclxuICAgICAgPHN0eWxlPlxyXG4gICAgICAgICoge1xyXG4gICAgICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5pbmRpY2F0b3Ige1xyXG4gICAgICAgICAgd2lkdGg6IDI4cHg7XHJcbiAgICAgICAgICBoZWlnaHQ6IDI4cHg7XHJcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kOiAjRkZDMTA3O1xyXG4gICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgICAgICAgIGJveC1zaGFkb3c6IDAgMnB4IDhweCByZ2JhKDAsIDAsIDAsIDAuMik7XHJcbiAgICAgICAgICBhbmltYXRpb246IHB1bHNlIDEuNXMgaW5maW5pdGU7XHJcbiAgICAgICAgICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMC4ycyBlYXNlO1xyXG4gICAgICAgICAgZm9udC1mYW1pbHk6IHN5c3RlbS11aSwgLWFwcGxlLXN5c3RlbSwgc2Fucy1zZXJpZjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5pbmRpY2F0b3I6aG92ZXIge1xyXG4gICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxLjEpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgQGtleWZyYW1lcyBwdWxzZSB7XHJcbiAgICAgICAgICAwJSwgMTAwJSB7IG9wYWNpdHk6IDE7IH1cclxuICAgICAgICAgIDUwJSB7IG9wYWNpdHk6IDAuNjsgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgQGtleWZyYW1lcyBzcGluIHtcclxuICAgICAgICAgIGZyb20geyB0cmFuc2Zvcm06IHJvdGF0ZSgwZGVnKTsgfVxyXG4gICAgICAgICAgdG8geyB0cmFuc2Zvcm06IHJvdGF0ZSgzNjBkZWcpOyB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuc3Bpbm5lciB7XHJcbiAgICAgICAgICB3aWR0aDogMTRweDtcclxuICAgICAgICAgIGhlaWdodDogMTRweDtcclxuICAgICAgICAgIGJvcmRlcjogMnB4IHNvbGlkIHdoaXRlO1xyXG4gICAgICAgICAgYm9yZGVyLXRvcC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgICBhbmltYXRpb246IHNwaW4gMXMgbGluZWFyIGluZmluaXRlO1xyXG4gICAgICAgIH1cclxuICAgICAgPC9zdHlsZT5cclxuICAgICAgPGRpdiBjbGFzcz1cImluZGljYXRvclwiIGFyaWEtbGFiZWw9XCJGYWN0IGNoZWNrIGluIHByb2dyZXNzXCIgcm9sZT1cInN0YXR1c1wiPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJzcGlubmVyXCI+PC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgYDtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFNob3cgcmVzdWx0IHdpdGggdmVyZGljdCBpY29uXHJcbiAgICovXHJcbiAgc2hvd1Jlc3VsdChyZXN1bHQ6IHtcclxuICAgIHZlcmRpY3Q6IFZlcmRpY3Q7XHJcbiAgICBjb25maWRlbmNlOiBudW1iZXI7XHJcbiAgICBleHBsYW5hdGlvbjogc3RyaW5nO1xyXG4gICAgc291cmNlczogQXJyYXk8eyB0aXRsZTogc3RyaW5nOyB1cmw6IHN0cmluZyB9PjtcclxuICAgIHByb3ZpZGVyUmVzdWx0cz86IEFycmF5PHtcclxuICAgICAgcHJvdmlkZXJJZDogc3RyaW5nO1xyXG4gICAgICBwcm92aWRlck5hbWU6IHN0cmluZztcclxuICAgICAgdmVyZGljdDogJ3RydWUnIHwgJ2ZhbHNlJyB8ICd1bmtub3duJztcclxuICAgICAgY29uZmlkZW5jZTogbnVtYmVyO1xyXG4gICAgICBleHBsYW5hdGlvbjogc3RyaW5nO1xyXG4gICAgfT47XHJcbiAgICBjb25zZW5zdXM/OiB7XHJcbiAgICAgIHRvdGFsOiBudW1iZXI7XHJcbiAgICAgIGFncmVlaW5nOiBudW1iZXI7XHJcbiAgICB9O1xyXG4gIH0pOiB2b2lkIHtcclxuICAgIGNvbnN0IGNvbG9yczogUmVjb3JkPFZlcmRpY3QsIHN0cmluZz4gPSB7XHJcbiAgICAgIHRydWU6ICcjNENBRjUwJyxcclxuICAgICAgZmFsc2U6ICcjZjQ0MzM2JyxcclxuICAgICAgdW5rbm93bjogJyNGRkMxMDcnLFxyXG4gICAgICBub19jbGFpbTogJyM5RTlFOUUnLFxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBpY29uczogUmVjb3JkPFZlcmRpY3QsIHN0cmluZz4gPSB7XHJcbiAgICAgIHRydWU6ICfinJMnLFxyXG4gICAgICBmYWxzZTogJ+KclycsXHJcbiAgICAgIHVua25vd246ICc/JyxcclxuICAgICAgbm9fY2xhaW06ICfil4snLFxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBsYWJlbHM6IFJlY29yZDxWZXJkaWN0LCBzdHJpbmc+ID0ge1xyXG4gICAgICB0cnVlOiAnRmFjdCBjaGVjayByZXN1bHQ6IHZlcmlmaWVkIHRydWUnLFxyXG4gICAgICBmYWxzZTogJ0ZhY3QgY2hlY2sgcmVzdWx0OiB2ZXJpZmllZCBmYWxzZScsXHJcbiAgICAgIHVua25vd246ICdGYWN0IGNoZWNrIHJlc3VsdDogdW52ZXJpZmlhYmxlJyxcclxuICAgICAgbm9fY2xhaW06ICdObyBmYWN0dWFsIGNsYWltcyBkZXRlY3RlZCcsXHJcbiAgICB9O1xyXG5cclxuICAgIHRoaXMuc2hhZG93Um9vdC5pbm5lckhUTUwgPSBgXHJcbiAgICAgIDxzdHlsZT5cclxuICAgICAgICAqIHtcclxuICAgICAgICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuaW5kaWNhdG9yIHtcclxuICAgICAgICAgIHdpZHRoOiAyOHB4O1xyXG4gICAgICAgICAgaGVpZ2h0OiAyOHB4O1xyXG4gICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgICAgYmFja2dyb3VuZDogJHtjb2xvcnNbcmVzdWx0LnZlcmRpY3RdfTtcclxuICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgICAgICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgICAgICAgIGJveC1zaGFkb3c6IDAgMnB4IDhweCByZ2JhKDAsIDAsIDAsIDAuMik7XHJcbiAgICAgICAgICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMC4ycyBlYXNlLCBib3gtc2hhZG93IDAuMnMgZWFzZTtcclxuICAgICAgICAgIGZvbnQtZmFtaWx5OiBzeXN0ZW0tdWksIC1hcHBsZS1zeXN0ZW0sIHNhbnMtc2VyaWY7XHJcbiAgICAgICAgICB1c2VyLXNlbGVjdDogbm9uZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5pbmRpY2F0b3I6aG92ZXIge1xyXG4gICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxLjE1KTtcclxuICAgICAgICAgIGJveC1zaGFkb3c6IDAgNHB4IDEycHggcmdiYSgwLCAwLCAwLCAwLjMpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmluZGljYXRvcjphY3RpdmUge1xyXG4gICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxLjA1KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIEBrZXlmcmFtZXMgc2NhbGVJbiB7XHJcbiAgICAgICAgICBmcm9tIHtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgwKTtcclxuICAgICAgICAgICAgb3BhY2l0eTogMDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHRvIHtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTtcclxuICAgICAgICAgICAgb3BhY2l0eTogMTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5pbmRpY2F0b3IuYW5pbWF0ZSB7XHJcbiAgICAgICAgICBhbmltYXRpb246IHNjYWxlSW4gMC4zcyBlYXNlLW91dDtcclxuICAgICAgICB9XHJcbiAgICAgIDwvc3R5bGU+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJpbmRpY2F0b3IgYW5pbWF0ZVwiXHJcbiAgICAgICAgICAgYXJpYS1sYWJlbD1cIiR7bGFiZWxzW3Jlc3VsdC52ZXJkaWN0XX1cIlxyXG4gICAgICAgICAgIHRhYmluZGV4PVwiMFwiXHJcbiAgICAgICAgICAgcm9sZT1cImJ1dHRvblwiPlxyXG4gICAgICAgICR7aWNvbnNbcmVzdWx0LnZlcmRpY3RdfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIGA7XHJcblxyXG4gICAgLy8gQWRkIGNsaWNrIGhhbmRsZXIgZm9yIHBvcHVwIChvbmx5IGlmIG5vdCBub19jbGFpbSlcclxuICAgIGlmIChyZXN1bHQudmVyZGljdCAhPT0gJ25vX2NsYWltJykge1xyXG4gICAgICBjb25zdCBpbmRpY2F0b3IgPSB0aGlzLnNoYWRvd1Jvb3QucXVlcnlTZWxlY3RvcignLmluZGljYXRvcicpO1xyXG4gICAgICBpbmRpY2F0b3I/LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGU6IEV2ZW50KSA9PiB7XHJcbiAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTsgLy8gUHJldmVudCBjbGljayBmcm9tIGJ1YmJsaW5nIHRvIHBvc3RcclxuICAgICAgICB0aGlzLnNob3dQb3B1cChyZXN1bHQpO1xyXG4gICAgICB9KTtcclxuICAgICAgaW5kaWNhdG9yPy5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgKGU6IEV2ZW50KSA9PiB7XHJcbiAgICAgICAgY29uc3Qga2V5RXZlbnQgPSBlIGFzIEtleWJvYXJkRXZlbnQ7XHJcbiAgICAgICAgaWYgKGtleUV2ZW50LmtleSA9PT0gJ0VudGVyJyB8fCBrZXlFdmVudC5rZXkgPT09ICcgJykge1xyXG4gICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTsgLy8gUHJldmVudCBldmVudCBmcm9tIGJ1YmJsaW5nIHRvIHBvc3RcclxuICAgICAgICAgIHRoaXMuc2hvd1BvcHVwKHJlc3VsdCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFNob3cgZGV0YWlsZWQgZXhwbGFuYXRpb24gcG9wdXBcclxuICAgKi9cclxuICBwcml2YXRlIHNob3dQb3B1cChyZXN1bHQ6IHtcclxuICAgIHZlcmRpY3Q6IFZlcmRpY3Q7XHJcbiAgICBjb25maWRlbmNlOiBudW1iZXI7XHJcbiAgICBleHBsYW5hdGlvbjogc3RyaW5nO1xyXG4gICAgc291cmNlczogQXJyYXk8eyB0aXRsZTogc3RyaW5nOyB1cmw6IHN0cmluZyB9PjtcclxuICAgIHByb3ZpZGVyUmVzdWx0cz86IEFycmF5PHtcclxuICAgICAgcHJvdmlkZXJJZDogc3RyaW5nO1xyXG4gICAgICBwcm92aWRlck5hbWU6IHN0cmluZztcclxuICAgICAgdmVyZGljdDogJ3RydWUnIHwgJ2ZhbHNlJyB8ICd1bmtub3duJztcclxuICAgICAgY29uZmlkZW5jZTogbnVtYmVyO1xyXG4gICAgICBleHBsYW5hdGlvbjogc3RyaW5nO1xyXG4gICAgfT47XHJcbiAgICBjb25zZW5zdXM/OiB7XHJcbiAgICAgIHRvdGFsOiBudW1iZXI7XHJcbiAgICAgIGFncmVlaW5nOiBudW1iZXI7XHJcbiAgICB9O1xyXG4gIH0pOiB2b2lkIHtcclxuICAgIC8vIENsb3NlIGV4aXN0aW5nIHBvcHVwIGlmIGFueVxyXG4gICAgaWYgKHRoaXMucG9wdXApIHtcclxuICAgICAgdGhpcy5wb3B1cC5oaWRlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gQ3JlYXRlIG5ldyBwb3B1cFxyXG4gICAgdGhpcy5wb3B1cCA9IG5ldyBGYWN0Q2hlY2tQb3B1cCh0aGlzLmVsZW1lbnQsIHJlc3VsdCk7XHJcbiAgICB0aGlzLnBvcHVwLnNob3coKTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFJlbW92ZSBpbmRpY2F0b3IgZnJvbSBET01cclxuICAgKi9cclxuICByZW1vdmUoKTogdm9pZCB7XHJcbiAgICBpZiAodGhpcy5wb3B1cCkge1xyXG4gICAgICB0aGlzLnBvcHVwLmhpZGUoKTtcclxuICAgIH1cclxuICAgIHRoaXMuZWxlbWVudC5yZW1vdmUoKTtcclxuICB9XHJcbn1cclxuIiwiLyoqXHJcbiAqIE1hbnVhbCBDaGVjayBCdXR0b24gQ29tcG9uZW50XHJcbiAqIERpc3BsYXllZCB3aGVuIGF1dG8tY2hlY2sgaXMgZGlzYWJsZWQsIGFsbG93cyB1c2VycyB0byBtYW51YWxseSB0cmlnZ2VyIGZhY3QtY2hlY2tpbmdcclxuICovXHJcblxyXG5leHBvcnQgY2xhc3MgQ2hlY2tCdXR0b24ge1xyXG4gIHByaXZhdGUgZWxlbWVudDogSFRNTERpdkVsZW1lbnQ7XHJcbiAgcHJpdmF0ZSBzaGFkb3dSb290OiBTaGFkb3dSb290O1xyXG4gIHByaXZhdGUgb25DaGVja0NhbGxiYWNrOiAoKCkgPT4gdm9pZCkgfCBudWxsID0gbnVsbDtcclxuICBwdWJsaWMgcmVhZG9ubHkgcGFyZW50RWxlbWVudDogRWxlbWVudDsgLy8gUHVibGljIGZvciBhY2Nlc3Mgd2hlbiByZXBsYWNpbmcgd2l0aCBpbmRpY2F0b3JcclxuXHJcbiAgY29uc3RydWN0b3IoXHJcbiAgICBwYXJlbnRFbGVtZW50OiBFbGVtZW50LFxyXG4gICAgcHJpdmF0ZSBlbGVtZW50SWQ6IHN0cmluZ1xyXG4gICkge1xyXG4gICAgdGhpcy5wYXJlbnRFbGVtZW50ID0gcGFyZW50RWxlbWVudDtcclxuICAgIHRoaXMuZWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gICAgdGhpcy5lbGVtZW50LmlkID0gYGZhY3QtY2hlY2stYnV0dG9uLSR7dGhpcy5lbGVtZW50SWR9YDtcclxuXHJcbiAgICAvLyBVc2UgU2hhZG93IERPTSBmb3Igc3R5bGUgaXNvbGF0aW9uXHJcbiAgICB0aGlzLnNoYWRvd1Jvb3QgPSB0aGlzLmVsZW1lbnQuYXR0YWNoU2hhZG93KHsgbW9kZTogJ2Nsb3NlZCcgfSk7XHJcblxyXG4gICAgLy8gUG9zaXRpb24gYWJzb2x1dGVseSBzbGlnaHRseSBvdXRzaWRlIHRvcC1yaWdodCBjb3JuZXIgb2YgY2FyZFxyXG4gICAgdGhpcy5lbGVtZW50LnN0eWxlLnBvc2l0aW9uID0gJ2Fic29sdXRlJztcclxuICAgIHRoaXMuZWxlbWVudC5zdHlsZS50b3AgPSAnLTEwcHgnO1xyXG4gICAgdGhpcy5lbGVtZW50LnN0eWxlLnJpZ2h0ID0gJy0xMHB4JztcclxuICAgIHRoaXMuZWxlbWVudC5zdHlsZS56SW5kZXggPSAnMjE0NzQ4MzY0Nyc7IC8vIE1heGltdW0gei1pbmRleFxyXG5cclxuICAgIHRoaXMuc2hvd0J1dHRvbigpO1xyXG4gICAgdGhpcy5hdHRhY2hUb1BhcmVudCgpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogQXR0YWNoIGJ1dHRvbiB0byBwYXJlbnQgZWxlbWVudFxyXG4gICAqL1xyXG4gIHByaXZhdGUgYXR0YWNoVG9QYXJlbnQoKTogdm9pZCB7XHJcbiAgICAvLyBNYWtlIHBhcmVudCByZWxhdGl2ZWx5IHBvc2l0aW9uZWQgaWYgbmVlZGVkXHJcbiAgICBjb25zdCBwYXJlbnRTdHlsZSA9IHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKHRoaXMucGFyZW50RWxlbWVudCk7XHJcbiAgICBpZiAocGFyZW50U3R5bGUucG9zaXRpb24gPT09ICdzdGF0aWMnKSB7XHJcbiAgICAgICh0aGlzLnBhcmVudEVsZW1lbnQgYXMgSFRNTEVsZW1lbnQpLnN0eWxlLnBvc2l0aW9uID0gJ3JlbGF0aXZlJztcclxuICAgIH1cclxuXHJcbiAgICB0aGlzLnBhcmVudEVsZW1lbnQuYXBwZW5kQ2hpbGQodGhpcy5lbGVtZW50KTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFNldCBjYWxsYmFjayBmb3Igd2hlbiB1c2VyIGNsaWNrcyBjaGVjayBidXR0b25cclxuICAgKi9cclxuICBvbkNoZWNrKGNhbGxiYWNrOiAoKSA9PiB2b2lkKTogdm9pZCB7XHJcbiAgICB0aGlzLm9uQ2hlY2tDYWxsYmFjayA9IGNhbGxiYWNrO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogU2hvdyB0aGUgbWFudWFsIGNoZWNrIGJ1dHRvbiAoY2lyY3VsYXIgYmFkZ2Ugc3R5bGUgbWF0Y2hpbmcgaW5kaWNhdG9yKVxyXG4gICAqL1xyXG4gIHByaXZhdGUgc2hvd0J1dHRvbigpOiB2b2lkIHtcclxuICAgIHRoaXMuc2hhZG93Um9vdC5pbm5lckhUTUwgPSBgXHJcbiAgICAgIDxzdHlsZT5cclxuICAgICAgICAqIHtcclxuICAgICAgICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuY2hlY2stYnV0dG9uIHtcclxuICAgICAgICAgIHdpZHRoOiAyOHB4O1xyXG4gICAgICAgICAgaGVpZ2h0OiAyOHB4O1xyXG4gICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgICAgYmFja2dyb3VuZDogIzE5NzZEMjtcclxuICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgICAgICAgIGJvcmRlcjogbm9uZTtcclxuICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgICAgICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgICAgICAgIGJveC1zaGFkb3c6IDAgMnB4IDhweCByZ2JhKDAsIDAsIDAsIDAuMik7XHJcbiAgICAgICAgICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMC4ycyBlYXNlLCBib3gtc2hhZG93IDAuMnMgZWFzZSwgYmFja2dyb3VuZCAwLjJzIGVhc2U7XHJcbiAgICAgICAgICBmb250LWZhbWlseTogc3lzdGVtLXVpLCAtYXBwbGUtc3lzdGVtLCBzYW5zLXNlcmlmO1xyXG4gICAgICAgICAgdXNlci1zZWxlY3Q6IG5vbmU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuY2hlY2stYnV0dG9uOmhvdmVyIHtcclxuICAgICAgICAgIGJhY2tncm91bmQ6ICMxNTY1QzA7XHJcbiAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEuMTUpO1xyXG4gICAgICAgICAgYm94LXNoYWRvdzogMCA0cHggMTJweCByZ2JhKDAsIDAsIDAsIDAuMyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuY2hlY2stYnV0dG9uOmFjdGl2ZSB7XHJcbiAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEuMDUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgQGtleWZyYW1lcyBzY2FsZUluIHtcclxuICAgICAgICAgIGZyb20ge1xyXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDApO1xyXG4gICAgICAgICAgICBvcGFjaXR5OiAwO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgdG8ge1xyXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpO1xyXG4gICAgICAgICAgICBvcGFjaXR5OiAxO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmNoZWNrLWJ1dHRvbi5hbmltYXRlIHtcclxuICAgICAgICAgIGFuaW1hdGlvbjogc2NhbGVJbiAwLjNzIGVhc2Utb3V0O1xyXG4gICAgICAgIH1cclxuICAgICAgPC9zdHlsZT5cclxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImNoZWNrLWJ1dHRvbiBhbmltYXRlXCJcclxuICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiQ2xpY2sgdG8gZmFjdC1jaGVjayB0aGlzIHBvc3RcIlxyXG4gICAgICAgICAgICAgIHRhYmluZGV4PVwiMFwiXHJcbiAgICAgICAgICAgICAgcm9sZT1cImJ1dHRvblwiPlxyXG4gICAgICAgIOKWtlxyXG4gICAgICA8L2J1dHRvbj5cclxuICAgIGA7XHJcblxyXG4gICAgLy8gQWRkIGNsaWNrIGhhbmRsZXJcclxuICAgIGNvbnN0IGJ1dHRvbiA9IHRoaXMuc2hhZG93Um9vdC5xdWVyeVNlbGVjdG9yKCcuY2hlY2stYnV0dG9uJyk7XHJcbiAgICBidXR0b24/LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGU6IEV2ZW50KSA9PiB7XHJcbiAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICAgIHRoaXMuaGFuZGxlQ2xpY2soKTtcclxuICAgIH0pO1xyXG5cclxuICAgIGJ1dHRvbj8uYWRkRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIChlOiBFdmVudCkgPT4ge1xyXG4gICAgICBjb25zdCBrZXlFdmVudCA9IGUgYXMgS2V5Ym9hcmRFdmVudDtcclxuICAgICAgaWYgKGtleUV2ZW50LmtleSA9PT0gJ0VudGVyJyB8fCBrZXlFdmVudC5rZXkgPT09ICcgJykge1xyXG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgICAgIHRoaXMuaGFuZGxlQ2xpY2soKTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBIYW5kbGUgYnV0dG9uIGNsaWNrXHJcbiAgICovXHJcbiAgcHJpdmF0ZSBoYW5kbGVDbGljaygpOiB2b2lkIHtcclxuICAgIC8vIFRyYW5zaXRpb24gdG8gbG9hZGluZyBzdGF0ZVxyXG4gICAgdGhpcy5zaG93TG9hZGluZygpO1xyXG5cclxuICAgIC8vIENhbGwgdGhlIGNhbGxiYWNrXHJcbiAgICBpZiAodGhpcy5vbkNoZWNrQ2FsbGJhY2spIHtcclxuICAgICAgdGhpcy5vbkNoZWNrQ2FsbGJhY2soKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFNob3cgbG9hZGluZyBzdGF0ZSAoY2FsbGVkIHdoZW4gdXNlciBjbGlja3MgYnV0dG9uKVxyXG4gICAqL1xyXG4gIHNob3dMb2FkaW5nKCk6IHZvaWQge1xyXG4gICAgdGhpcy5zaGFkb3dSb290LmlubmVySFRNTCA9IGBcclxuICAgICAgPHN0eWxlPlxyXG4gICAgICAgICoge1xyXG4gICAgICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5pbmRpY2F0b3Ige1xyXG4gICAgICAgICAgd2lkdGg6IDI4cHg7XHJcbiAgICAgICAgICBoZWlnaHQ6IDI4cHg7XHJcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kOiAjRkZDMTA3O1xyXG4gICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAgIGN1cnNvcjogd2FpdDtcclxuICAgICAgICAgIGJveC1zaGFkb3c6IDAgMnB4IDhweCByZ2JhKDAsIDAsIDAsIDAuMik7XHJcbiAgICAgICAgICBhbmltYXRpb246IHB1bHNlIDEuNXMgaW5maW5pdGU7XHJcbiAgICAgICAgICBmb250LWZhbWlseTogc3lzdGVtLXVpLCAtYXBwbGUtc3lzdGVtLCBzYW5zLXNlcmlmO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgQGtleWZyYW1lcyBwdWxzZSB7XHJcbiAgICAgICAgICAwJSwgMTAwJSB7IG9wYWNpdHk6IDE7IH1cclxuICAgICAgICAgIDUwJSB7IG9wYWNpdHk6IDAuNjsgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgQGtleWZyYW1lcyBzcGluIHtcclxuICAgICAgICAgIGZyb20geyB0cmFuc2Zvcm06IHJvdGF0ZSgwZGVnKTsgfVxyXG4gICAgICAgICAgdG8geyB0cmFuc2Zvcm06IHJvdGF0ZSgzNjBkZWcpOyB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuc3Bpbm5lciB7XHJcbiAgICAgICAgICB3aWR0aDogMTRweDtcclxuICAgICAgICAgIGhlaWdodDogMTRweDtcclxuICAgICAgICAgIGJvcmRlcjogMnB4IHNvbGlkIHdoaXRlO1xyXG4gICAgICAgICAgYm9yZGVyLXRvcC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgICBhbmltYXRpb246IHNwaW4gMXMgbGluZWFyIGluZmluaXRlO1xyXG4gICAgICAgIH1cclxuICAgICAgPC9zdHlsZT5cclxuICAgICAgPGRpdiBjbGFzcz1cImluZGljYXRvclwiIGFyaWEtbGFiZWw9XCJGYWN0IGNoZWNrIGluIHByb2dyZXNzXCIgcm9sZT1cInN0YXR1c1wiPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJzcGlubmVyXCI+PC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgYDtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFJlbW92ZSBidXR0b24gZnJvbSBET01cclxuICAgKi9cclxuICByZW1vdmUoKTogdm9pZCB7XHJcbiAgICB0aGlzLmVsZW1lbnQucmVtb3ZlKCk7XHJcbiAgfVxyXG59XHJcbiJdLCJuYW1lcyI6WyJGYWN0Q2hlY2tQb3B1cCIsImFuY2hvckVsZW1lbnQiLCJyZXN1bHQiLCJlIiwicmVjdCIsInBvcHVwV2lkdGgiLCJwb3B1cEhlaWdodCIsInRvcCIsImxlZnQiLCJ2aWV3cG9ydFdpZHRoIiwidmlld3BvcnRIZWlnaHQiLCJ2ZXJkaWN0Q29sb3JzIiwidmVyZGljdExhYmVscyIsInNvdXJjZSIsImRvbWFpbiIsInBvcHVwRWxlbWVudCIsImNsb3NlQnRuIiwidGFyZ2V0IiwidW5zYWZlIiwidXJsIiwidGV4dCIsIm1heExlbmd0aCIsInByb3ZpZGVyU2hvcnROYW1lcyIsInByb3ZpZGVyIiwiRmFjdENoZWNrSW5kaWNhdG9yIiwicGFyZW50RWxlbWVudCIsImVsZW1lbnRJZCIsImNvbG9ycyIsImljb25zIiwibGFiZWxzIiwiaW5kaWNhdG9yIiwia2V5RXZlbnQiLCJDaGVja0J1dHRvbiIsImNhbGxiYWNrIiwiYnV0dG9uIl0sIm1hcHBpbmdzIjoiQUFPTyxNQUFNQSxDQUFlLENBSzFCLFlBQ1VDLEVBQ0FDLEVBaUJSLENBbEJRLEtBQUEsY0FBQUQsRUFDQSxLQUFBLE9BQUFDLEVBaVlWLEtBQVEsZ0JBQW1CQyxHQUEyQixDQUNoREEsRUFBRSxNQUFRLFVBQ1osS0FBSyxLQUFBLENBRVQsRUFuWEUsS0FBSyxRQUFVLFNBQVMsY0FBYyxLQUFLLEVBQzNDLEtBQUssV0FBYSxLQUFLLFFBQVEsYUFBYSxDQUFFLEtBQU0sU0FBVSxFQUU5RCxLQUFLLFFBQVEsTUFBTSxTQUFXLFFBQzlCLEtBQUssUUFBUSxNQUFNLE9BQVMsYUFFNUIsS0FBSyx3QkFBMEIsS0FBSyxtQkFBbUIsS0FBSyxJQUFJLEVBRWhFLFNBQVMsS0FBSyxZQUFZLEtBQUssT0FBTyxDQUN4QyxDQUtBLE1BQWEsQ0FDWCxNQUFNQyxFQUFPLEtBQUssY0FBYyxzQkFBQSxFQUcxQkMsRUFBYSxJQUNiQyxFQUFjLElBQ3BCLElBQUlDLEVBQU1ILEVBQUssT0FBUyxFQUNwQkksRUFBT0osRUFBSyxNQUFRQyxFQUd4QixNQUFNSSxFQUFnQixPQUFPLFdBQ3ZCQyxFQUFpQixPQUFPLFlBRzFCRixFQUFPLElBQ1RBLEVBQU8sR0FFTEEsRUFBT0gsRUFBYUksRUFBZ0IsSUFDdENELEVBQU9DLEVBQWdCSixFQUFhLEdBSWxDRSxFQUFNRCxFQUFjSSxFQUFpQixJQUN2Q0gsRUFBTUgsRUFBSyxJQUFNRSxFQUFjLEVBQzNCQyxFQUFNLElBQ1JBLEVBQU0sSUFJVixLQUFLLFFBQVEsTUFBTSxJQUFNLEdBQUdBLENBQUcsS0FDL0IsS0FBSyxRQUFRLE1BQU0sS0FBTyxHQUFHQyxDQUFJLEtBRWpDLE1BQU1HLEVBQXlDLENBQzdDLEtBQU0sVUFDTixNQUFPLFVBQ1AsUUFBUyxVQUNULFNBQVUsU0FBQSxFQUdOQyxFQUF5QyxDQUM3QyxLQUFNLGdCQUNOLE1BQU8saUJBQ1AsUUFBUyxlQUNULFNBQVUsV0FBQSxFQUdaLEtBQUssV0FBVyxVQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBcUNSRCxFQUFjLEtBQUssT0FBTyxPQUFPLENBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkE2RGxDQSxFQUFjLEtBQUssT0FBTyxPQUFPLENBQUM7QUFBQSxtQkFDdkMsS0FBSyxPQUFPLFVBQVU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQXVIUkMsRUFBYyxLQUFLLE9BQU8sT0FBTyxDQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkNBVXhCLEtBQUssc0JBQXNCO0FBQUE7QUFBQTtBQUFBLHFDQUdqQyxLQUFLLFdBQVcsS0FBSyxPQUFPLFdBQVcsQ0FBQztBQUFBO0FBQUEsWUFHakUsS0FBSyxPQUFPLFFBQVEsT0FBUyxFQUN6QjtBQUFBO0FBQUE7QUFBQSxnQkFHQSxLQUFLLE9BQU8sUUFDWCxJQUFLQyxHQUFXLENBQ2YsTUFBTUMsRUFBUyxLQUFLLGNBQWNELEVBQU8sR0FBRyxFQUM1QyxNQUFPO0FBQUE7QUFBQSw2QkFFSSxLQUFLLFdBQVdBLEVBQU8sR0FBRyxDQUFDLHNEQUFzRCxLQUFLLFdBQVdBLEVBQU8sS0FBSyxDQUFDO0FBQUEsc0JBQ3JILEtBQUssV0FBVyxLQUFLLFNBQVNBLEVBQU8sTUFBTyxFQUFFLENBQUMsQ0FBQztBQUFBO0FBQUEsK0NBRXZCLEtBQUssV0FBV0MsQ0FBTSxDQUFDO0FBQUE7QUFBQSxlQUd0RCxDQUFDLEVBQ0EsS0FBSyxFQUFFLENBQUM7QUFBQTtBQUFBLFlBR1QsRUFDTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BVU4sTUFBTUMsRUFBZSxLQUFLLFdBQVcsY0FBYyxRQUFRLEVBQzNEQSxHQUFBLE1BQUFBLEVBQWMsaUJBQWlCLFFBQVVaLEdBQWEsQ0FDcERBLEVBQUUsZ0JBQUEsQ0FDSixHQUdBLE1BQU1hLEVBQVcsS0FBSyxXQUFXLGNBQWMsUUFBUSxFQUN2REEsR0FBQSxNQUFBQSxFQUFVLGlCQUFpQixRQUFTLElBQU0sS0FBSyxRQUcvQyxXQUFXLElBQU0sQ0FDZixTQUFTLGlCQUFpQixRQUFTLEtBQUssdUJBQXVCLENBQ2pFLEVBQUcsR0FBRyxFQUdOLFNBQVMsaUJBQWlCLFVBQVcsS0FBSyxlQUFlLENBQzNELENBS0EsTUFBYSxDQUNYLFNBQVMsb0JBQW9CLFFBQVMsS0FBSyx1QkFBdUIsRUFDbEUsU0FBUyxvQkFBb0IsVUFBVyxLQUFLLGVBQWUsRUFDNUQsS0FBSyxRQUFRLE9BQUEsQ0FDZixDQUtRLG1CQUFtQixFQUFxQixDQUM5QyxNQUFNQyxFQUFTLEVBQUUsT0FFZixDQUFDLEtBQUssUUFBUSxTQUFTQSxDQUFNLEdBQzdCLENBQUMsS0FBSyxjQUFjLFNBQVNBLENBQU0sR0FFbkMsS0FBSyxLQUFBLENBRVQsQ0FjUSxXQUFXQyxFQUF3QixDQUN6QyxPQUFPQSxFQUNKLFFBQVEsS0FBTSxPQUFPLEVBQ3JCLFFBQVEsS0FBTSxNQUFNLEVBQ3BCLFFBQVEsS0FBTSxNQUFNLEVBQ3BCLFFBQVEsS0FBTSxRQUFRLEVBQ3RCLFFBQVEsS0FBTSxRQUFRLENBQzNCLENBS1EsY0FBY0MsRUFBcUIsQ0FDekMsR0FBSSxDQUVGLE9BRGUsSUFBSSxJQUFJQSxDQUFHLEVBQ1osU0FBUyxRQUFRLFNBQVUsRUFBRSxDQUM3QyxNQUFRLENBQ04sT0FBT0EsQ0FDVCxDQUNGLENBS1EsU0FBU0MsRUFBY0MsRUFBMkIsQ0FDeEQsT0FBSUQsRUFBSyxRQUFVQyxFQUFrQkQsRUFDOUJBLEVBQUssVUFBVSxFQUFHQyxFQUFZLENBQUMsRUFBSSxLQUM1QyxDQUtRLHNCQUErQixDQUNyQyxHQUFJLENBQUMsS0FBSyxPQUFPLGlCQUFtQixLQUFLLE9BQU8sZ0JBQWdCLFNBQVcsRUFDekUsTUFBTyxHQUFHLEtBQUssT0FBTyxVQUFVLGNBSWxDLE1BQU1DLEVBQTZDLENBQ2pELE9BQVEsU0FDUixVQUFXLFlBQ1gsV0FBWSxZQUFBLEVBVWQsTUFBTztBQUFBO0FBQUEsVUFQZ0IsS0FBSyxPQUFPLGdCQUNoQyxJQUFLQyxHQUVHLG1FQURXRCxFQUFtQkMsRUFBUyxVQUFVLEdBQUtBLEVBQVMsWUFDYSxZQUFZQSxFQUFTLFVBQVUsVUFDbkgsRUFDQSxLQUFLLEVBQUUsQ0FJVTtBQUFBO0FBQUEseUNBRWlCLEtBQUssT0FBTyxVQUFVO0FBQUEsS0FFN0QsQ0FDRixDQzFjTyxNQUFNQyxDQUFtQixDQUs5QixZQUNVQyxFQUNBQyxFQUNSLENBRlEsS0FBQSxjQUFBRCxFQUNBLEtBQUEsVUFBQUMsRUFKVixLQUFRLE1BQStCLEtBTXJDLEtBQUssUUFBVSxTQUFTLGNBQWMsS0FBSyxFQUMzQyxLQUFLLFFBQVEsR0FBSyx3QkFBd0IsS0FBSyxTQUFTLEdBR3hELEtBQUssV0FBYSxLQUFLLFFBQVEsYUFBYSxDQUFFLEtBQU0sU0FBVSxFQUc5RCxLQUFLLFFBQVEsTUFBTSxTQUFXLFdBQzlCLEtBQUssUUFBUSxNQUFNLElBQU0sUUFDekIsS0FBSyxRQUFRLE1BQU0sTUFBUSxRQUMzQixLQUFLLFFBQVEsTUFBTSxPQUFTLGFBRTVCLEtBQUssWUFBQSxFQUNMLEtBQUssZUFBQSxDQUNQLENBS1EsZ0JBQXVCLENBRVQsT0FBTyxpQkFBaUIsS0FBSyxhQUFhLEVBQzlDLFdBQWEsV0FDMUIsS0FBSyxjQUE4QixNQUFNLFNBQVcsWUFHdkQsS0FBSyxjQUFjLFlBQVksS0FBSyxPQUFPLENBQzdDLENBS0EsYUFBb0IsQ0FDbEIsS0FBSyxXQUFXLFVBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBZ0Q5QixDQUtBLFdBQVd4QixFQWdCRixDQUNQLE1BQU15QixFQUFrQyxDQUN0QyxLQUFNLFVBQ04sTUFBTyxVQUNQLFFBQVMsVUFDVCxTQUFVLFNBQUEsRUFHTkMsRUFBaUMsQ0FDckMsS0FBTSxJQUNOLE1BQU8sSUFDUCxRQUFTLElBQ1QsU0FBVSxHQUFBLEVBR05DLEVBQWtDLENBQ3RDLEtBQU0sbUNBQ04sTUFBTyxvQ0FDUCxRQUFTLGtDQUNULFNBQVUsNEJBQUEsRUE0RFosR0F6REEsS0FBSyxXQUFXLFVBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFVUkYsRUFBT3pCLEVBQU8sT0FBTyxDQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXVDckIyQixFQUFPM0IsRUFBTyxPQUFPLENBQUM7QUFBQTtBQUFBO0FBQUEsVUFHckMwQixFQUFNMUIsRUFBTyxPQUFPLENBQUM7QUFBQTtBQUFBLE1BS3ZCQSxFQUFPLFVBQVksV0FBWSxDQUNqQyxNQUFNNEIsRUFBWSxLQUFLLFdBQVcsY0FBYyxZQUFZLEVBQzVEQSxHQUFBLE1BQUFBLEVBQVcsaUJBQWlCLFFBQVUzQixHQUFhLENBQ2pEQSxFQUFFLGdCQUFBLEVBQ0YsS0FBSyxVQUFVRCxDQUFNLENBQ3ZCLEdBQ0E0QixHQUFBLE1BQUFBLEVBQVcsaUJBQWlCLFVBQVkzQixHQUFhLENBQ25ELE1BQU00QixFQUFXNUIsR0FDYjRCLEVBQVMsTUFBUSxTQUFXQSxFQUFTLE1BQVEsT0FDL0M1QixFQUFFLGVBQUEsRUFDRkEsRUFBRSxnQkFBQSxFQUNGLEtBQUssVUFBVUQsQ0FBTSxFQUV6QixFQUNGLENBQ0YsQ0FLUSxVQUFVQSxFQWdCVCxDQUVILEtBQUssT0FDUCxLQUFLLE1BQU0sS0FBQSxFQUliLEtBQUssTUFBUSxJQUFJRixFQUFlLEtBQUssUUFBU0UsQ0FBTSxFQUNwRCxLQUFLLE1BQU0sS0FBQSxDQUNiLENBS0EsUUFBZSxDQUNULEtBQUssT0FDUCxLQUFLLE1BQU0sS0FBQSxFQUViLEtBQUssUUFBUSxPQUFBLENBQ2YsQ0FDRixDQ3pQTyxNQUFNOEIsQ0FBWSxDQU12QixZQUNFUCxFQUNRQyxFQUNSLENBRFEsS0FBQSxVQUFBQSxFQUxWLEtBQVEsZ0JBQXVDLEtBTzdDLEtBQUssY0FBZ0JELEVBQ3JCLEtBQUssUUFBVSxTQUFTLGNBQWMsS0FBSyxFQUMzQyxLQUFLLFFBQVEsR0FBSyxxQkFBcUIsS0FBSyxTQUFTLEdBR3JELEtBQUssV0FBYSxLQUFLLFFBQVEsYUFBYSxDQUFFLEtBQU0sU0FBVSxFQUc5RCxLQUFLLFFBQVEsTUFBTSxTQUFXLFdBQzlCLEtBQUssUUFBUSxNQUFNLElBQU0sUUFDekIsS0FBSyxRQUFRLE1BQU0sTUFBUSxRQUMzQixLQUFLLFFBQVEsTUFBTSxPQUFTLGFBRTVCLEtBQUssV0FBQSxFQUNMLEtBQUssZUFBQSxDQUNQLENBS1EsZ0JBQXVCLENBRVQsT0FBTyxpQkFBaUIsS0FBSyxhQUFhLEVBQzlDLFdBQWEsV0FDMUIsS0FBSyxjQUE4QixNQUFNLFNBQVcsWUFHdkQsS0FBSyxjQUFjLFlBQVksS0FBSyxPQUFPLENBQzdDLENBS0EsUUFBUVEsRUFBNEIsQ0FDbEMsS0FBSyxnQkFBa0JBLENBQ3pCLENBS1EsWUFBbUIsQ0FDekIsS0FBSyxXQUFXLFVBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BMkQ1QixNQUFNQyxFQUFTLEtBQUssV0FBVyxjQUFjLGVBQWUsRUFDNURBLEdBQUEsTUFBQUEsRUFBUSxpQkFBaUIsUUFBVS9CLEdBQWEsQ0FDOUNBLEVBQUUsZ0JBQUEsRUFDRixLQUFLLFlBQUEsQ0FDUCxHQUVBK0IsR0FBQSxNQUFBQSxFQUFRLGlCQUFpQixVQUFZL0IsR0FBYSxDQUNoRCxNQUFNNEIsRUFBVzVCLEdBQ2I0QixFQUFTLE1BQVEsU0FBV0EsRUFBUyxNQUFRLE9BQy9DNUIsRUFBRSxlQUFBLEVBQ0ZBLEVBQUUsZ0JBQUEsRUFDRixLQUFLLFlBQUEsRUFFVCxFQUNGLENBS1EsYUFBb0IsQ0FFMUIsS0FBSyxZQUFBLEVBR0QsS0FBSyxpQkFDUCxLQUFLLGdCQUFBLENBRVQsQ0FLQSxhQUFvQixDQUNsQixLQUFLLFdBQVcsVUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQTJDOUIsQ0FLQSxRQUFlLENBQ2IsS0FBSyxRQUFRLE9BQUEsQ0FDZixDQUNGIn0=
