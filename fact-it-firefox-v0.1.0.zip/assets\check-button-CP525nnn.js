class m{constructor(e,t){this.anchorElement=e,this.result=t,this.handleEscapeKey=i=>{i.key==="Escape"&&this.hide()},this.element=document.createElement("div"),this.shadowRoot=this.element.attachShadow({mode:"closed"}),this.element.style.position="fixed",this.element.style.zIndex="2147483647",this.boundHandleOutsideClick=this.handleOutsideClick.bind(this),document.body.appendChild(this.element)}show(){const e=this.anchorElement.getBoundingClientRect(),t=320,i=400;let s=e.bottom+8,o=e.right-t;const n=window.innerWidth,a=window.innerHeight;o<8&&(o=8),o+t>n-8&&(o=n-t-8),s+i>a-8&&(s=e.top-i-8,s<8&&(s=8)),this.element.style.top=`${s}px`,this.element.style.left=`${o}px`;const h={true:"#4CAF50",false:"#f44336",unknown:"#FFC107",no_claim:"#9E9E9E"},p={true:"Verified True",false:"Verified False",unknown:"Unverifiable",no_claim:"No Claims"};this.shadowRoot.innerHTML=`
      <style>
        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
        }

        .popup {
          width: 320px;
          max-height: 400px;
          background: white;
          border-radius: 12px;
          box-shadow: 0 8px 24px rgba(0, 0, 0, 0.25);
          overflow: hidden;
          font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
          font-size: 14px;
          line-height: 1.5;
          animation: slideIn 0.2s ease-out;
        }

        @keyframes slideIn {
          from {
            opacity: 0;
            transform: translateY(-8px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 16px;
          background: ${h[this.result.verdict]};
          color: white;
        }

        .verdict {
          font-weight: 600;
          font-size: 16px;
        }

        .close {
          background: none;
          border: none;
          font-size: 24px;
          cursor: pointer;
          padding: 0;
          width: 28px;
          height: 28px;
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          border-radius: 50%;
          transition: background 0.2s;
          line-height: 1;
        }

        .close:hover {
          background: rgba(255, 255, 255, 0.2);
        }

        .close:active {
          background: rgba(255, 255, 255, 0.3);
        }

        .content {
          padding: 16px;
          max-height: 320px;
          overflow-y: auto;
        }

        .confidence {
          margin-bottom: 16px;
        }

        .confidence-label {
          font-size: 12px;
          color: #666;
          margin-bottom: 6px;
          font-weight: 500;
        }

        .confidence-bar {
          width: 100%;
          height: 8px;
          background: #E0E0E0;
          border-radius: 4px;
          overflow: hidden;
        }

        .confidence-fill {
          height: 100%;
          background: ${h[this.result.verdict]};
          width: ${this.result.confidence}%;
          transition: width 0.5s ease-out;
          border-radius: 4px;
        }

        .confidence-text {
          font-size: 11px;
          color: #888;
          margin-top: 4px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 8px;
        }

        .provider-scores {
          display: flex;
          gap: 8px;
          align-items: center;
        }

        .provider-score {
          font-size: 11px;
          color: #888;
        }

        .provider-score-label {
          font-weight: 500;
        }

        .overall-score {
          font-weight: 600;
        }

        .explanation {
          margin-bottom: 16px;
          color: #333;
          line-height: 1.6;
        }

        .sources {
          margin-top: 16px;
          padding-top: 16px;
          border-top: 1px solid #E0E0E0;
        }

        .sources-title {
          font-weight: 600;
          margin-bottom: 10px;
          color: #333;
          font-size: 13px;
        }

        .source {
          margin-bottom: 10px;
        }

        .source:last-child {
          margin-bottom: 0;
        }

        .source a {
          color: #1976D2;
          text-decoration: none;
          font-size: 13px;
          line-height: 1.4;
          display: block;
          transition: color 0.2s;
        }

        .source a:hover {
          color: #1565C0;
          text-decoration: underline;
        }

        .source-domain {
          font-size: 11px;
          color: #999;
          margin-top: 2px;
        }

        .footer {
          padding: 12px 16px;
          background: #F5F5F5;
          border-top: 1px solid #E0E0E0;
          text-align: center;
          font-size: 11px;
          color: #666;
        }

        .footer a {
          color: #1976D2;
          text-decoration: none;
        }

        .footer a:hover {
          text-decoration: underline;
        }

        /* Scrollbar styling */
        .content::-webkit-scrollbar {
          width: 6px;
        }

        .content::-webkit-scrollbar-track {
          background: #F5F5F5;
        }

        .content::-webkit-scrollbar-thumb {
          background: #CCC;
          border-radius: 3px;
        }

        .content::-webkit-scrollbar-thumb:hover {
          background: #999;
        }
      </style>
      <div class="popup">
        <div class="header">
          <div class="verdict">${p[this.result.verdict]}</div>
          <button class="close" aria-label="Close" title="Close">×</button>
        </div>

        <div class="content">
          <div class="confidence">
            <div class="confidence-label">Overall Confidence</div>
            <div class="confidence-bar">
              <div class="confidence-fill"></div>
            </div>
            <div class="confidence-text">${this.renderProviderScores()}</div>
          </div>

          <div class="explanation">${this.escapeHtml(this.result.explanation)}</div>

          ${this.result.sources.length>0?`
            <div class="sources">
              <div class="sources-title">Sources</div>
              ${this.result.sources.map(r=>{const u=this.extractDomain(r.url);return`
                <div class="source">
                  <a href="${this.escapeHtml(r.url)}" target="_blank" rel="noopener noreferrer" title="${this.escapeHtml(r.title)}">
                    ${this.escapeHtml(this.truncate(r.title,60))}
                  </a>
                  <div class="source-domain">${this.escapeHtml(u)}</div>
                </div>
              `}).join("")}
            </div>
          `:""}
        </div>

        <div class="footer">
          Powered by <a href="https://github.com/yourusername/fact-it" target="_blank">Fact-It</a> • AI-generated verification
        </div>
      </div>
    `;const c=this.shadowRoot.querySelector(".popup");c==null||c.addEventListener("click",r=>{r.stopPropagation()});const l=this.shadowRoot.querySelector(".close");l==null||l.addEventListener("click",()=>this.hide()),setTimeout(()=>{document.addEventListener("click",this.boundHandleOutsideClick)},100),document.addEventListener("keydown",this.handleEscapeKey)}hide(){document.removeEventListener("click",this.boundHandleOutsideClick),document.removeEventListener("keydown",this.handleEscapeKey),this.element.remove()}handleOutsideClick(e){const t=e.target;!this.element.contains(t)&&!this.anchorElement.contains(t)&&this.hide()}escapeHtml(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}extractDomain(e){try{return new URL(e).hostname.replace(/^www\./,"")}catch{return e}}truncate(e,t){return e.length<=t?e:e.substring(0,t-3)+"..."}renderProviderScores(){if(!this.result.providerResults||this.result.providerResults.length===0)return`${this.result.confidence}% confident`;const e={openai:"OpenAI",anthropic:"Anthropic",perplexity:"Perplexity"};return`
      <div class="provider-scores">
        ${this.result.providerResults.map(i=>`<span class="provider-score"><span class="provider-score-label">${e[i.providerId]||i.providerName}:</span> ${i.confidence}%</span>`).join("")}
      </div>
      <span class="overall-score">Agg: ${this.result.confidence}%</span>
    `}}class f{constructor(e,t){this.parentElement=e,this.elementId=t,this.popup=null,this.element=document.createElement("div"),this.element.id=`fact-check-indicator-${this.elementId}`,this.shadowRoot=this.element.attachShadow({mode:"closed"}),this.element.style.position="absolute",this.element.style.top="-10px",this.element.style.right="-10px",this.element.style.zIndex="2147483647",this.showLoading(),this.attachToParent()}attachToParent(){window.getComputedStyle(this.parentElement).position==="static"&&(this.parentElement.style.position="relative"),this.parentElement.appendChild(this.element)}showLoading(){this.shadowRoot.innerHTML=`
      <style>
        * {
          box-sizing: border-box;
        }

        .indicator {
          width: 28px;
          height: 28px;
          border-radius: 50%;
          background: #FFC107;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
          animation: pulse 1.5s infinite;
          transition: transform 0.2s ease;
          font-family: system-ui, -apple-system, sans-serif;
        }

        .indicator:hover {
          transform: scale(1.1);
        }

        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.6; }
        }

        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }

        .spinner {
          width: 14px;
          height: 14px;
          border: 2px solid white;
          border-top-color: transparent;
          border-radius: 50%;
          animation: spin 1s linear infinite;
        }
      </style>
      <div class="indicator" aria-label="Fact check in progress" role="status">
        <div class="spinner"></div>
      </div>
    `}showResult(e){const t={true:"#4CAF50",false:"#f44336",unknown:"#FFC107",no_claim:"#9E9E9E"},i={true:"✓",false:"✗",unknown:"?",no_claim:"○"},s={true:"Fact check result: verified true",false:"Fact check result: verified false",unknown:"Fact check result: unverifiable",no_claim:"No factual claims detected"};if(this.shadowRoot.innerHTML=`
      <style>
        * {
          box-sizing: border-box;
        }

        .indicator {
          width: 28px;
          height: 28px;
          border-radius: 50%;
          background: ${t[e.verdict]};
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: bold;
          font-size: 16px;
          cursor: pointer;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
          transition: transform 0.2s ease, box-shadow 0.2s ease;
          font-family: system-ui, -apple-system, sans-serif;
          user-select: none;
        }

        .indicator:hover {
          transform: scale(1.15);
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        }

        .indicator:active {
          transform: scale(1.05);
        }

        @keyframes scaleIn {
          from {
            transform: scale(0);
            opacity: 0;
          }
          to {
            transform: scale(1);
            opacity: 1;
          }
        }

        .indicator.animate {
          animation: scaleIn 0.3s ease-out;
        }
      </style>
      <div class="indicator animate"
           aria-label="${s[e.verdict]}"
           tabindex="0"
           role="button">
        ${i[e.verdict]}
      </div>
    `,e.verdict!=="no_claim"){const o=this.shadowRoot.querySelector(".indicator");o==null||o.addEventListener("click",n=>{n.stopPropagation(),this.showPopup(e)}),o==null||o.addEventListener("keydown",n=>{const a=n;(a.key==="Enter"||a.key===" ")&&(n.preventDefault(),n.stopPropagation(),this.showPopup(e))})}}showPopup(e){this.popup&&this.popup.hide(),this.popup=new m(this.element,e),this.popup.show()}remove(){this.popup&&this.popup.hide(),this.element.remove()}}class b{constructor(e,t){this.elementId=t,this.onCheckCallback=null,this.parentElement=e,this.element=document.createElement("div"),this.element.id=`fact-check-button-${this.elementId}`,this.shadowRoot=this.element.attachShadow({mode:"closed"}),this.element.style.position="absolute",this.element.style.top="-10px",this.element.style.right="-10px",this.element.style.zIndex="2147483647",this.showButton(),this.attachToParent()}attachToParent(){window.getComputedStyle(this.parentElement).position==="static"&&(this.parentElement.style.position="relative"),this.parentElement.appendChild(this.element)}onCheck(e){this.onCheckCallback=e}showButton(){this.shadowRoot.innerHTML=`
      <style>
        * {
          box-sizing: border-box;
        }

        .check-button {
          width: 28px;
          height: 28px;
          border-radius: 50%;
          background: #1976D2;
          color: white;
          border: none;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: bold;
          font-size: 16px;
          cursor: pointer;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
          transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
          font-family: system-ui, -apple-system, sans-serif;
          user-select: none;
        }

        .check-button:hover {
          background: #1565C0;
          transform: scale(1.15);
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        }

        .check-button:active {
          transform: scale(1.05);
        }

        @keyframes scaleIn {
          from {
            transform: scale(0);
            opacity: 0;
          }
          to {
            transform: scale(1);
            opacity: 1;
          }
        }

        .check-button.animate {
          animation: scaleIn 0.3s ease-out;
        }
      </style>
      <button class="check-button animate"
              aria-label="Click to fact-check this post"
              tabindex="0"
              role="button">
        ▶
      </button>
    `;const e=this.shadowRoot.querySelector(".check-button");e==null||e.addEventListener("click",t=>{t.stopPropagation(),this.handleClick()}),e==null||e.addEventListener("keydown",t=>{const i=t;(i.key==="Enter"||i.key===" ")&&(t.preventDefault(),t.stopPropagation(),this.handleClick())})}handleClick(){this.showLoading(),this.onCheckCallback&&this.onCheckCallback()}showLoading(){this.shadowRoot.innerHTML=`
      <style>
        * {
          box-sizing: border-box;
        }

        .indicator {
          width: 28px;
          height: 28px;
          border-radius: 50%;
          background: #FFC107;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: wait;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
          animation: pulse 1.5s infinite;
          font-family: system-ui, -apple-system, sans-serif;
        }

        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.6; }
        }

        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }

        .spinner {
          width: 14px;
          height: 14px;
          border: 2px solid white;
          border-top-color: transparent;
          border-radius: 50%;
          animation: spin 1s linear infinite;
        }
      </style>
      <div class="indicator" aria-label="Fact check in progress" role="status">
        <div class="spinner"></div>
      </div>
    `}remove(){this.element.remove()}}export{b as C,f as F};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hlY2stYnV0dG9uLUNQNTI1bm5uLmpzIiwic291cmNlcyI6WyIuLi8uLi9zcmMvY29udGVudC91aS9wb3B1cC50cyIsIi4uLy4uL3NyYy9jb250ZW50L3VpL2luZGljYXRvci50cyIsIi4uLy4uL3NyYy9jb250ZW50L3VpL2NoZWNrLWJ1dHRvbi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogRmFjdCBDaGVjayBQb3B1cCBDb21wb25lbnRcclxuICogU2hvd3MgZGV0YWlsZWQgZXhwbGFuYXRpb24sIGNvbmZpZGVuY2Ugc2NvcmUsIGFuZCBzb3VyY2VzXHJcbiAqL1xyXG5cclxuaW1wb3J0IHsgVmVyZGljdCB9IGZyb20gJ0Avc2hhcmVkL3R5cGVzJztcclxuXHJcbmV4cG9ydCBjbGFzcyBGYWN0Q2hlY2tQb3B1cCB7XHJcbiAgcHJpdmF0ZSBlbGVtZW50OiBIVE1MRGl2RWxlbWVudDtcclxuICBwcml2YXRlIHNoYWRvd1Jvb3Q6IFNoYWRvd1Jvb3Q7XHJcbiAgcHJpdmF0ZSBib3VuZEhhbmRsZU91dHNpZGVDbGljazogKGU6IE1vdXNlRXZlbnQpID0+IHZvaWQ7XHJcblxyXG4gIGNvbnN0cnVjdG9yKFxyXG4gICAgcHJpdmF0ZSBhbmNob3JFbGVtZW50OiBIVE1MRWxlbWVudCxcclxuICAgIHByaXZhdGUgcmVzdWx0OiB7XHJcbiAgICAgIHZlcmRpY3Q6IFZlcmRpY3Q7XHJcbiAgICAgIGNvbmZpZGVuY2U6IG51bWJlcjtcclxuICAgICAgZXhwbGFuYXRpb246IHN0cmluZztcclxuICAgICAgc291cmNlczogQXJyYXk8eyB0aXRsZTogc3RyaW5nOyB1cmw6IHN0cmluZyB9PjtcclxuICAgICAgcHJvdmlkZXJSZXN1bHRzPzogQXJyYXk8e1xyXG4gICAgICAgIHByb3ZpZGVySWQ6IHN0cmluZztcclxuICAgICAgICBwcm92aWRlck5hbWU6IHN0cmluZztcclxuICAgICAgICB2ZXJkaWN0OiAndHJ1ZScgfCAnZmFsc2UnIHwgJ3Vua25vd24nO1xyXG4gICAgICAgIGNvbmZpZGVuY2U6IG51bWJlcjtcclxuICAgICAgICBleHBsYW5hdGlvbjogc3RyaW5nO1xyXG4gICAgICB9PjtcclxuICAgICAgY29uc2Vuc3VzPzoge1xyXG4gICAgICAgIHRvdGFsOiBudW1iZXI7XHJcbiAgICAgICAgYWdyZWVpbmc6IG51bWJlcjtcclxuICAgICAgfTtcclxuICAgIH1cclxuICApIHtcclxuICAgIHRoaXMuZWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gICAgdGhpcy5zaGFkb3dSb290ID0gdGhpcy5lbGVtZW50LmF0dGFjaFNoYWRvdyh7IG1vZGU6ICdjbG9zZWQnIH0pO1xyXG5cclxuICAgIHRoaXMuZWxlbWVudC5zdHlsZS5wb3NpdGlvbiA9ICdmaXhlZCc7XHJcbiAgICB0aGlzLmVsZW1lbnQuc3R5bGUuekluZGV4ID0gJzIxNDc0ODM2NDcnO1xyXG5cclxuICAgIHRoaXMuYm91bmRIYW5kbGVPdXRzaWRlQ2xpY2sgPSB0aGlzLmhhbmRsZU91dHNpZGVDbGljay5iaW5kKHRoaXMpO1xyXG5cclxuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQodGhpcy5lbGVtZW50KTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFNob3cgdGhlIHBvcHVwXHJcbiAgICovXHJcbiAgc2hvdygpOiB2b2lkIHtcclxuICAgIGNvbnN0IHJlY3QgPSB0aGlzLmFuY2hvckVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XHJcblxyXG4gICAgLy8gUG9zaXRpb24gYmVsb3cgYW5kIHRvIHRoZSBsZWZ0IG9mIGluZGljYXRvciAoaW5kaWNhdG9yIGlzIGluIHRvcC1yaWdodCBjb3JuZXIpXHJcbiAgICBjb25zdCBwb3B1cFdpZHRoID0gMzIwO1xyXG4gICAgY29uc3QgcG9wdXBIZWlnaHQgPSA0MDA7XHJcbiAgICBsZXQgdG9wID0gcmVjdC5ib3R0b20gKyA4OyAvLyBQb3NpdGlvbiBiZWxvdyBpbmRpY2F0b3JcclxuICAgIGxldCBsZWZ0ID0gcmVjdC5yaWdodCAtIHBvcHVwV2lkdGg7IC8vIEFsaWduIHJpZ2h0IGVkZ2Ugb2YgcG9wdXAgd2l0aCBpbmRpY2F0b3JcclxuXHJcbiAgICAvLyBFbnN1cmUgcG9wdXAgc3RheXMgd2l0aGluIHZpZXdwb3J0XHJcbiAgICBjb25zdCB2aWV3cG9ydFdpZHRoID0gd2luZG93LmlubmVyV2lkdGg7XHJcbiAgICBjb25zdCB2aWV3cG9ydEhlaWdodCA9IHdpbmRvdy5pbm5lckhlaWdodDtcclxuXHJcbiAgICAvLyBBZGp1c3QgaG9yaXpvbnRhbCBwb3NpdGlvbiBpZiBuZWVkZWRcclxuICAgIGlmIChsZWZ0IDwgOCkge1xyXG4gICAgICBsZWZ0ID0gODsgLy8gTWluIGxlZnQgcGFkZGluZ1xyXG4gICAgfVxyXG4gICAgaWYgKGxlZnQgKyBwb3B1cFdpZHRoID4gdmlld3BvcnRXaWR0aCAtIDgpIHtcclxuICAgICAgbGVmdCA9IHZpZXdwb3J0V2lkdGggLSBwb3B1cFdpZHRoIC0gODsgLy8gTWF4IHJpZ2h0IHBhZGRpbmdcclxuICAgIH1cclxuXHJcbiAgICAvLyBJZiBwb3B1cCB3b3VsZCBnbyBiZWxvdyB2aWV3cG9ydCwgcG9zaXRpb24gYWJvdmUgaW5kaWNhdG9yIGluc3RlYWRcclxuICAgIGlmICh0b3AgKyBwb3B1cEhlaWdodCA+IHZpZXdwb3J0SGVpZ2h0IC0gOCkge1xyXG4gICAgICB0b3AgPSByZWN0LnRvcCAtIHBvcHVwSGVpZ2h0IC0gODtcclxuICAgICAgaWYgKHRvcCA8IDgpIHtcclxuICAgICAgICB0b3AgPSA4OyAvLyBGYWxsYmFjayB0byB0b3Agb2Ygdmlld3BvcnRcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHRoaXMuZWxlbWVudC5zdHlsZS50b3AgPSBgJHt0b3B9cHhgO1xyXG4gICAgdGhpcy5lbGVtZW50LnN0eWxlLmxlZnQgPSBgJHtsZWZ0fXB4YDtcclxuXHJcbiAgICBjb25zdCB2ZXJkaWN0Q29sb3JzOiBSZWNvcmQ8VmVyZGljdCwgc3RyaW5nPiA9IHtcclxuICAgICAgdHJ1ZTogJyM0Q0FGNTAnLFxyXG4gICAgICBmYWxzZTogJyNmNDQzMzYnLFxyXG4gICAgICB1bmtub3duOiAnI0ZGQzEwNycsXHJcbiAgICAgIG5vX2NsYWltOiAnIzlFOUU5RScsXHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IHZlcmRpY3RMYWJlbHM6IFJlY29yZDxWZXJkaWN0LCBzdHJpbmc+ID0ge1xyXG4gICAgICB0cnVlOiAnVmVyaWZpZWQgVHJ1ZScsXHJcbiAgICAgIGZhbHNlOiAnVmVyaWZpZWQgRmFsc2UnLFxyXG4gICAgICB1bmtub3duOiAnVW52ZXJpZmlhYmxlJyxcclxuICAgICAgbm9fY2xhaW06ICdObyBDbGFpbXMnLFxyXG4gICAgfTtcclxuXHJcbiAgICB0aGlzLnNoYWRvd1Jvb3QuaW5uZXJIVE1MID0gYFxyXG4gICAgICA8c3R5bGU+XHJcbiAgICAgICAgKiB7XHJcbiAgICAgICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5wb3B1cCB7XHJcbiAgICAgICAgICB3aWR0aDogMzIwcHg7XHJcbiAgICAgICAgICBtYXgtaGVpZ2h0OiA0MDBweDtcclxuICAgICAgICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAgICAgICAgYm9yZGVyLXJhZGl1czogMTJweDtcclxuICAgICAgICAgIGJveC1zaGFkb3c6IDAgOHB4IDI0cHggcmdiYSgwLCAwLCAwLCAwLjI1KTtcclxuICAgICAgICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICAgICAgICBmb250LWZhbWlseTogc3lzdGVtLXVpLCAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsICdTZWdvZSBVSScsIHNhbnMtc2VyaWY7XHJcbiAgICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgICAgICBsaW5lLWhlaWdodDogMS41O1xyXG4gICAgICAgICAgYW5pbWF0aW9uOiBzbGlkZUluIDAuMnMgZWFzZS1vdXQ7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBAa2V5ZnJhbWVzIHNsaWRlSW4ge1xyXG4gICAgICAgICAgZnJvbSB7XHJcbiAgICAgICAgICAgIG9wYWNpdHk6IDA7XHJcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtOHB4KTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHRvIHtcclxuICAgICAgICAgICAgb3BhY2l0eTogMTtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmhlYWRlciB7XHJcbiAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICAgIHBhZGRpbmc6IDE2cHg7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kOiAke3ZlcmRpY3RDb2xvcnNbdGhpcy5yZXN1bHQudmVyZGljdF19O1xyXG4gICAgICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLnZlcmRpY3Qge1xyXG4gICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5jbG9zZSB7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kOiBub25lO1xyXG4gICAgICAgICAgYm9yZGVyOiBub25lO1xyXG4gICAgICAgICAgZm9udC1zaXplOiAyNHB4O1xyXG4gICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICAgIHdpZHRoOiAyOHB4O1xyXG4gICAgICAgICAgaGVpZ2h0OiAyOHB4O1xyXG4gICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICAgIHRyYW5zaXRpb246IGJhY2tncm91bmQgMC4ycztcclxuICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmNsb3NlOmhvdmVyIHtcclxuICAgICAgICAgIGJhY2tncm91bmQ6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC4yKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5jbG9zZTphY3RpdmUge1xyXG4gICAgICAgICAgYmFja2dyb3VuZDogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjMpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmNvbnRlbnQge1xyXG4gICAgICAgICAgcGFkZGluZzogMTZweDtcclxuICAgICAgICAgIG1heC1oZWlnaHQ6IDMyMHB4O1xyXG4gICAgICAgICAgb3ZlcmZsb3cteTogYXV0bztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5jb25maWRlbmNlIHtcclxuICAgICAgICAgIG1hcmdpbi1ib3R0b206IDE2cHg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuY29uZmlkZW5jZS1sYWJlbCB7XHJcbiAgICAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICAgICAgICBjb2xvcjogIzY2NjtcclxuICAgICAgICAgIG1hcmdpbi1ib3R0b206IDZweDtcclxuICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuY29uZmlkZW5jZS1iYXIge1xyXG4gICAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgICBoZWlnaHQ6IDhweDtcclxuICAgICAgICAgIGJhY2tncm91bmQ6ICNFMEUwRTA7XHJcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICAgICAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmNvbmZpZGVuY2UtZmlsbCB7XHJcbiAgICAgICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kOiAke3ZlcmRpY3RDb2xvcnNbdGhpcy5yZXN1bHQudmVyZGljdF19O1xyXG4gICAgICAgICAgd2lkdGg6ICR7dGhpcy5yZXN1bHQuY29uZmlkZW5jZX0lO1xyXG4gICAgICAgICAgdHJhbnNpdGlvbjogd2lkdGggMC41cyBlYXNlLW91dDtcclxuICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5jb25maWRlbmNlLXRleHQge1xyXG4gICAgICAgICAgZm9udC1zaXplOiAxMXB4O1xyXG4gICAgICAgICAgY29sb3I6ICM4ODg7XHJcbiAgICAgICAgICBtYXJnaW4tdG9wOiA0cHg7XHJcbiAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICAgIGdhcDogOHB4O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLnByb3ZpZGVyLXNjb3JlcyB7XHJcbiAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgZ2FwOiA4cHg7XHJcbiAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLnByb3ZpZGVyLXNjb3JlIHtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMTFweDtcclxuICAgICAgICAgIGNvbG9yOiAjODg4O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLnByb3ZpZGVyLXNjb3JlLWxhYmVsIHtcclxuICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAub3ZlcmFsbC1zY29yZSB7XHJcbiAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmV4cGxhbmF0aW9uIHtcclxuICAgICAgICAgIG1hcmdpbi1ib3R0b206IDE2cHg7XHJcbiAgICAgICAgICBjb2xvcjogIzMzMztcclxuICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxLjY7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuc291cmNlcyB7XHJcbiAgICAgICAgICBtYXJnaW4tdG9wOiAxNnB4O1xyXG4gICAgICAgICAgcGFkZGluZy10b3A6IDE2cHg7XHJcbiAgICAgICAgICBib3JkZXItdG9wOiAxcHggc29saWQgI0UwRTBFMDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5zb3VyY2VzLXRpdGxlIHtcclxuICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG4gICAgICAgICAgY29sb3I6ICMzMzM7XHJcbiAgICAgICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuc291cmNlIHtcclxuICAgICAgICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuc291cmNlOmxhc3QtY2hpbGQge1xyXG4gICAgICAgICAgbWFyZ2luLWJvdHRvbTogMDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5zb3VyY2UgYSB7XHJcbiAgICAgICAgICBjb2xvcjogIzE5NzZEMjtcclxuICAgICAgICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxLjQ7XHJcbiAgICAgICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgICAgICAgIHRyYW5zaXRpb246IGNvbG9yIDAuMnM7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuc291cmNlIGE6aG92ZXIge1xyXG4gICAgICAgICAgY29sb3I6ICMxNTY1QzA7XHJcbiAgICAgICAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5zb3VyY2UtZG9tYWluIHtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMTFweDtcclxuICAgICAgICAgIGNvbG9yOiAjOTk5O1xyXG4gICAgICAgICAgbWFyZ2luLXRvcDogMnB4O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmZvb3RlciB7XHJcbiAgICAgICAgICBwYWRkaW5nOiAxMnB4IDE2cHg7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kOiAjRjVGNUY1O1xyXG4gICAgICAgICAgYm9yZGVyLXRvcDogMXB4IHNvbGlkICNFMEUwRTA7XHJcbiAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICBmb250LXNpemU6IDExcHg7XHJcbiAgICAgICAgICBjb2xvcjogIzY2NjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5mb290ZXIgYSB7XHJcbiAgICAgICAgICBjb2xvcjogIzE5NzZEMjtcclxuICAgICAgICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5mb290ZXIgYTpob3ZlciB7XHJcbiAgICAgICAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8qIFNjcm9sbGJhciBzdHlsaW5nICovXHJcbiAgICAgICAgLmNvbnRlbnQ6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcclxuICAgICAgICAgIHdpZHRoOiA2cHg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuY29udGVudDo6LXdlYmtpdC1zY3JvbGxiYXItdHJhY2sge1xyXG4gICAgICAgICAgYmFja2dyb3VuZDogI0Y1RjVGNTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5jb250ZW50Ojotd2Via2l0LXNjcm9sbGJhci10aHVtYiB7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kOiAjQ0NDO1xyXG4gICAgICAgICAgYm9yZGVyLXJhZGl1czogM3B4O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmNvbnRlbnQ6Oi13ZWJraXQtc2Nyb2xsYmFyLXRodW1iOmhvdmVyIHtcclxuICAgICAgICAgIGJhY2tncm91bmQ6ICM5OTk7XHJcbiAgICAgICAgfVxyXG4gICAgICA8L3N0eWxlPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwicG9wdXBcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwiaGVhZGVyXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwidmVyZGljdFwiPiR7dmVyZGljdExhYmVsc1t0aGlzLnJlc3VsdC52ZXJkaWN0XX08L2Rpdj5cclxuICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJjbG9zZVwiIGFyaWEtbGFiZWw9XCJDbG9zZVwiIHRpdGxlPVwiQ2xvc2VcIj7DlzwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwiY29udGVudFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImNvbmZpZGVuY2VcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbmZpZGVuY2UtbGFiZWxcIj5PdmVyYWxsIENvbmZpZGVuY2U8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbmZpZGVuY2UtYmFyXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbmZpZGVuY2UtZmlsbFwiPjwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbmZpZGVuY2UtdGV4dFwiPiR7dGhpcy5yZW5kZXJQcm92aWRlclNjb3JlcygpfTwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImV4cGxhbmF0aW9uXCI+JHt0aGlzLmVzY2FwZUh0bWwodGhpcy5yZXN1bHQuZXhwbGFuYXRpb24pfTwvZGl2PlxyXG5cclxuICAgICAgICAgICR7XHJcbiAgICAgICAgICAgIHRoaXMucmVzdWx0LnNvdXJjZXMubGVuZ3RoID4gMFxyXG4gICAgICAgICAgICAgID8gYFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwic291cmNlc1wiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzb3VyY2VzLXRpdGxlXCI+U291cmNlczwvZGl2PlxyXG4gICAgICAgICAgICAgICR7dGhpcy5yZXN1bHQuc291cmNlc1xyXG4gICAgICAgICAgICAgICAgLm1hcCgoc291cmNlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGRvbWFpbiA9IHRoaXMuZXh0cmFjdERvbWFpbihzb3VyY2UudXJsKTtcclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIGBcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzb3VyY2VcIj5cclxuICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cIiR7dGhpcy5lc2NhcGVIdG1sKHNvdXJjZS51cmwpfVwiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIiB0aXRsZT1cIiR7dGhpcy5lc2NhcGVIdG1sKHNvdXJjZS50aXRsZSl9XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgJHt0aGlzLmVzY2FwZUh0bWwodGhpcy50cnVuY2F0ZShzb3VyY2UudGl0bGUsIDYwKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNvdXJjZS1kb21haW5cIj4ke3RoaXMuZXNjYXBlSHRtbChkb21haW4pfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgYDtcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAuam9pbignJyl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgYFxyXG4gICAgICAgICAgICAgIDogJydcclxuICAgICAgICAgIH1cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImZvb3RlclwiPlxyXG4gICAgICAgICAgUG93ZXJlZCBieSA8YSBocmVmPVwiaHR0cHM6Ly9naXRodWIuY29tL3lvdXJ1c2VybmFtZS9mYWN0LWl0XCIgdGFyZ2V0PVwiX2JsYW5rXCI+RmFjdC1JdDwvYT4g4oCiIEFJLWdlbmVyYXRlZCB2ZXJpZmljYXRpb25cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICBgO1xyXG5cclxuICAgIC8vIFByZXZlbnQgY2xpY2tzIGluc2lkZSBwb3B1cCBmcm9tIGJ1YmJsaW5nIHRvIHVuZGVybHlpbmcgcGFnZVxyXG4gICAgY29uc3QgcG9wdXBFbGVtZW50ID0gdGhpcy5zaGFkb3dSb290LnF1ZXJ5U2VsZWN0b3IoJy5wb3B1cCcpO1xyXG4gICAgcG9wdXBFbGVtZW50Py5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIChlOiBFdmVudCkgPT4ge1xyXG4gICAgICBlLnN0b3BQcm9wYWdhdGlvbigpOyAvLyBQcmV2ZW50IGNsaWNrcyBmcm9tIGJ1YmJsaW5nIHRocm91Z2ggdG8gcG9zdFxyXG4gICAgfSk7XHJcblxyXG4gICAgLy8gQ2xvc2UgYnV0dG9uIGhhbmRsZXJcclxuICAgIGNvbnN0IGNsb3NlQnRuID0gdGhpcy5zaGFkb3dSb290LnF1ZXJ5U2VsZWN0b3IoJy5jbG9zZScpO1xyXG4gICAgY2xvc2VCdG4/LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4gdGhpcy5oaWRlKCkpO1xyXG5cclxuICAgIC8vIENsb3NlIG9uIGNsaWNrIG91dHNpZGUgKHdpdGggc21hbGwgZGVsYXkgdG8gYXZvaWQgaW1tZWRpYXRlIGNsb3NlKVxyXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgdGhpcy5ib3VuZEhhbmRsZU91dHNpZGVDbGljayk7XHJcbiAgICB9LCAxMDApO1xyXG5cclxuICAgIC8vIENsb3NlIG9uIEVzY2FwZSBrZXlcclxuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCB0aGlzLmhhbmRsZUVzY2FwZUtleSk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBIaWRlIHRoZSBwb3B1cFxyXG4gICAqL1xyXG4gIGhpZGUoKTogdm9pZCB7XHJcbiAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdjbGljaycsIHRoaXMuYm91bmRIYW5kbGVPdXRzaWRlQ2xpY2spO1xyXG4gICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIHRoaXMuaGFuZGxlRXNjYXBlS2V5KTtcclxuICAgIHRoaXMuZWxlbWVudC5yZW1vdmUoKTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEhhbmRsZSBjbGlja3Mgb3V0c2lkZSB0aGUgcG9wdXBcclxuICAgKi9cclxuICBwcml2YXRlIGhhbmRsZU91dHNpZGVDbGljayhlOiBNb3VzZUV2ZW50KTogdm9pZCB7XHJcbiAgICBjb25zdCB0YXJnZXQgPSBlLnRhcmdldCBhcyBOb2RlO1xyXG4gICAgaWYgKFxyXG4gICAgICAhdGhpcy5lbGVtZW50LmNvbnRhaW5zKHRhcmdldCkgJiZcclxuICAgICAgIXRoaXMuYW5jaG9yRWxlbWVudC5jb250YWlucyh0YXJnZXQpXHJcbiAgICApIHtcclxuICAgICAgdGhpcy5oaWRlKCk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBIYW5kbGUgRXNjYXBlIGtleSB0byBjbG9zZSBwb3B1cFxyXG4gICAqL1xyXG4gIHByaXZhdGUgaGFuZGxlRXNjYXBlS2V5ID0gKGU6IEtleWJvYXJkRXZlbnQpOiB2b2lkID0+IHtcclxuICAgIGlmIChlLmtleSA9PT0gJ0VzY2FwZScpIHtcclxuICAgICAgdGhpcy5oaWRlKCk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLyoqXHJcbiAgICogRXNjYXBlIEhUTUwgdG8gcHJldmVudCBYU1NcclxuICAgKi9cclxuICBwcml2YXRlIGVzY2FwZUh0bWwodW5zYWZlOiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgcmV0dXJuIHVuc2FmZVxyXG4gICAgICAucmVwbGFjZSgvJi9nLCAnJmFtcDsnKVxyXG4gICAgICAucmVwbGFjZSgvPC9nLCAnJmx0OycpXHJcbiAgICAgIC5yZXBsYWNlKC8+L2csICcmZ3Q7JylcclxuICAgICAgLnJlcGxhY2UoL1wiL2csICcmcXVvdDsnKVxyXG4gICAgICAucmVwbGFjZSgvJy9nLCAnJiMwMzk7Jyk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBFeHRyYWN0IGRvbWFpbiBmcm9tIFVSTFxyXG4gICAqL1xyXG4gIHByaXZhdGUgZXh0cmFjdERvbWFpbih1cmw6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCB1cmxPYmogPSBuZXcgVVJMKHVybCk7XHJcbiAgICAgIHJldHVybiB1cmxPYmouaG9zdG5hbWUucmVwbGFjZSgvXnd3d1xcLi8sICcnKTtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICByZXR1cm4gdXJsO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogVHJ1bmNhdGUgdGV4dCB0byBtYXggbGVuZ3RoXHJcbiAgICovXHJcbiAgcHJpdmF0ZSB0cnVuY2F0ZSh0ZXh0OiBzdHJpbmcsIG1heExlbmd0aDogbnVtYmVyKTogc3RyaW5nIHtcclxuICAgIGlmICh0ZXh0Lmxlbmd0aCA8PSBtYXhMZW5ndGgpIHJldHVybiB0ZXh0O1xyXG4gICAgcmV0dXJuIHRleHQuc3Vic3RyaW5nKDAsIG1heExlbmd0aCAtIDMpICsgJy4uLic7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBSZW5kZXIgcHJvdmlkZXIgc2NvcmVzIGlubGluZSBiZWxvdyBjb25maWRlbmNlIGJhclxyXG4gICAqL1xyXG4gIHByaXZhdGUgcmVuZGVyUHJvdmlkZXJTY29yZXMoKTogc3RyaW5nIHtcclxuICAgIGlmICghdGhpcy5yZXN1bHQucHJvdmlkZXJSZXN1bHRzIHx8IHRoaXMucmVzdWx0LnByb3ZpZGVyUmVzdWx0cy5sZW5ndGggPT09IDApIHtcclxuICAgICAgcmV0dXJuIGAke3RoaXMucmVzdWx0LmNvbmZpZGVuY2V9JSBjb25maWRlbnRgO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIE1hcCBwcm92aWRlciBJRHMgdG8gc2hvcnQgbmFtZXNcclxuICAgIGNvbnN0IHByb3ZpZGVyU2hvcnROYW1lczogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHtcclxuICAgICAgb3BlbmFpOiAnT3BlbkFJJyxcclxuICAgICAgYW50aHJvcGljOiAnQW50aHJvcGljJyxcclxuICAgICAgcGVycGxleGl0eTogJ1BlcnBsZXhpdHknLFxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBwcm92aWRlclNjb3JlcyA9IHRoaXMucmVzdWx0LnByb3ZpZGVyUmVzdWx0c1xyXG4gICAgICAubWFwKChwcm92aWRlcikgPT4ge1xyXG4gICAgICAgIGNvbnN0IHNob3J0TmFtZSA9IHByb3ZpZGVyU2hvcnROYW1lc1twcm92aWRlci5wcm92aWRlcklkXSB8fCBwcm92aWRlci5wcm92aWRlck5hbWU7XHJcbiAgICAgICAgcmV0dXJuIGA8c3BhbiBjbGFzcz1cInByb3ZpZGVyLXNjb3JlXCI+PHNwYW4gY2xhc3M9XCJwcm92aWRlci1zY29yZS1sYWJlbFwiPiR7c2hvcnROYW1lfTo8L3NwYW4+ICR7cHJvdmlkZXIuY29uZmlkZW5jZX0lPC9zcGFuPmA7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5qb2luKCcnKTtcclxuXHJcbiAgICByZXR1cm4gYFxyXG4gICAgICA8ZGl2IGNsYXNzPVwicHJvdmlkZXItc2NvcmVzXCI+XHJcbiAgICAgICAgJHtwcm92aWRlclNjb3Jlc31cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxzcGFuIGNsYXNzPVwib3ZlcmFsbC1zY29yZVwiPkFnZzogJHt0aGlzLnJlc3VsdC5jb25maWRlbmNlfSU8L3NwYW4+XHJcbiAgICBgO1xyXG4gIH1cclxufVxyXG4iLCIvKipcclxuICogRmFjdCBDaGVjayBJbmRpY2F0b3IgQ29tcG9uZW50XHJcbiAqIFZpc3VhbCBpbmRpY2F0b3Igc2hvd2luZyBmYWN0LWNoZWNrIHZlcmRpY3Qgd2l0aCBTaGFkb3cgRE9NIGZvciBzdHlsZSBpc29sYXRpb25cclxuICovXHJcblxyXG5pbXBvcnQgeyBWZXJkaWN0IH0gZnJvbSAnQC9zaGFyZWQvdHlwZXMnO1xyXG5pbXBvcnQgeyBGYWN0Q2hlY2tQb3B1cCB9IGZyb20gJy4vcG9wdXAnO1xyXG5cclxuZXhwb3J0IGNsYXNzIEZhY3RDaGVja0luZGljYXRvciB7XHJcbiAgcHJpdmF0ZSBlbGVtZW50OiBIVE1MRGl2RWxlbWVudDtcclxuICBwcml2YXRlIHNoYWRvd1Jvb3Q6IFNoYWRvd1Jvb3Q7XHJcbiAgcHJpdmF0ZSBwb3B1cDogRmFjdENoZWNrUG9wdXAgfCBudWxsID0gbnVsbDtcclxuXHJcbiAgY29uc3RydWN0b3IoXHJcbiAgICBwcml2YXRlIHBhcmVudEVsZW1lbnQ6IEVsZW1lbnQsXHJcbiAgICBwcml2YXRlIGVsZW1lbnRJZDogc3RyaW5nXHJcbiAgKSB7XHJcbiAgICB0aGlzLmVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcclxuICAgIHRoaXMuZWxlbWVudC5pZCA9IGBmYWN0LWNoZWNrLWluZGljYXRvci0ke3RoaXMuZWxlbWVudElkfWA7XHJcblxyXG4gICAgLy8gVXNlIFNoYWRvdyBET00gZm9yIHN0eWxlIGlzb2xhdGlvblxyXG4gICAgdGhpcy5zaGFkb3dSb290ID0gdGhpcy5lbGVtZW50LmF0dGFjaFNoYWRvdyh7IG1vZGU6ICdjbG9zZWQnIH0pO1xyXG5cclxuICAgIC8vIFBvc2l0aW9uIGFic29sdXRlbHkgc2xpZ2h0bHkgb3V0c2lkZSB0b3AtcmlnaHQgY29ybmVyIG9mIGNhcmRcclxuICAgIHRoaXMuZWxlbWVudC5zdHlsZS5wb3NpdGlvbiA9ICdhYnNvbHV0ZSc7XHJcbiAgICB0aGlzLmVsZW1lbnQuc3R5bGUudG9wID0gJy0xMHB4JztcclxuICAgIHRoaXMuZWxlbWVudC5zdHlsZS5yaWdodCA9ICctMTBweCc7XHJcbiAgICB0aGlzLmVsZW1lbnQuc3R5bGUuekluZGV4ID0gJzIxNDc0ODM2NDcnOyAvLyBNYXhpbXVtIHotaW5kZXhcclxuXHJcbiAgICB0aGlzLnNob3dMb2FkaW5nKCk7XHJcbiAgICB0aGlzLmF0dGFjaFRvUGFyZW50KCk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBBdHRhY2ggaW5kaWNhdG9yIHRvIHBhcmVudCBlbGVtZW50XHJcbiAgICovXHJcbiAgcHJpdmF0ZSBhdHRhY2hUb1BhcmVudCgpOiB2b2lkIHtcclxuICAgIC8vIE1ha2UgcGFyZW50IHJlbGF0aXZlbHkgcG9zaXRpb25lZCBpZiBuZWVkZWRcclxuICAgIGNvbnN0IHBhcmVudFN0eWxlID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUodGhpcy5wYXJlbnRFbGVtZW50KTtcclxuICAgIGlmIChwYXJlbnRTdHlsZS5wb3NpdGlvbiA9PT0gJ3N0YXRpYycpIHtcclxuICAgICAgKHRoaXMucGFyZW50RWxlbWVudCBhcyBIVE1MRWxlbWVudCkuc3R5bGUucG9zaXRpb24gPSAncmVsYXRpdmUnO1xyXG4gICAgfVxyXG5cclxuICAgIHRoaXMucGFyZW50RWxlbWVudC5hcHBlbmRDaGlsZCh0aGlzLmVsZW1lbnQpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogU2hvdyBsb2FkaW5nIHN0YXRlIChzcGlubmluZyBpbmRpY2F0b3IpXHJcbiAgICovXHJcbiAgc2hvd0xvYWRpbmcoKTogdm9pZCB7XHJcbiAgICB0aGlzLnNoYWRvd1Jvb3QuaW5uZXJIVE1MID0gYFxyXG4gICAgICA8c3R5bGU+XHJcbiAgICAgICAgKiB7XHJcbiAgICAgICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmluZGljYXRvciB7XHJcbiAgICAgICAgICB3aWR0aDogMjhweDtcclxuICAgICAgICAgIGhlaWdodDogMjhweDtcclxuICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICAgIGJhY2tncm91bmQ6ICNGRkMxMDc7XHJcbiAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgICAgICAgYm94LXNoYWRvdzogMCAycHggOHB4IHJnYmEoMCwgMCwgMCwgMC4yKTtcclxuICAgICAgICAgIGFuaW1hdGlvbjogcHVsc2UgMS41cyBpbmZpbml0ZTtcclxuICAgICAgICAgIHRyYW5zaXRpb246IHRyYW5zZm9ybSAwLjJzIGVhc2U7XHJcbiAgICAgICAgICBmb250LWZhbWlseTogc3lzdGVtLXVpLCAtYXBwbGUtc3lzdGVtLCBzYW5zLXNlcmlmO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmluZGljYXRvcjpob3ZlciB7XHJcbiAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEuMSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBAa2V5ZnJhbWVzIHB1bHNlIHtcclxuICAgICAgICAgIDAlLCAxMDAlIHsgb3BhY2l0eTogMTsgfVxyXG4gICAgICAgICAgNTAlIHsgb3BhY2l0eTogMC42OyB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBAa2V5ZnJhbWVzIHNwaW4ge1xyXG4gICAgICAgICAgZnJvbSB7IHRyYW5zZm9ybTogcm90YXRlKDBkZWcpOyB9XHJcbiAgICAgICAgICB0byB7IHRyYW5zZm9ybTogcm90YXRlKDM2MGRlZyk7IH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5zcGlubmVyIHtcclxuICAgICAgICAgIHdpZHRoOiAxNHB4O1xyXG4gICAgICAgICAgaGVpZ2h0OiAxNHB4O1xyXG4gICAgICAgICAgYm9yZGVyOiAycHggc29saWQgd2hpdGU7XHJcbiAgICAgICAgICBib3JkZXItdG9wLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICAgIGFuaW1hdGlvbjogc3BpbiAxcyBsaW5lYXIgaW5maW5pdGU7XHJcbiAgICAgICAgfVxyXG4gICAgICA8L3N0eWxlPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwiaW5kaWNhdG9yXCIgYXJpYS1sYWJlbD1cIkZhY3QgY2hlY2sgaW4gcHJvZ3Jlc3NcIiByb2xlPVwic3RhdHVzXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInNwaW5uZXJcIj48L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICBgO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogU2hvdyByZXN1bHQgd2l0aCB2ZXJkaWN0IGljb25cclxuICAgKi9cclxuICBzaG93UmVzdWx0KHJlc3VsdDoge1xyXG4gICAgdmVyZGljdDogVmVyZGljdDtcclxuICAgIGNvbmZpZGVuY2U6IG51bWJlcjtcclxuICAgIGV4cGxhbmF0aW9uOiBzdHJpbmc7XHJcbiAgICBzb3VyY2VzOiBBcnJheTx7IHRpdGxlOiBzdHJpbmc7IHVybDogc3RyaW5nIH0+O1xyXG4gICAgcHJvdmlkZXJSZXN1bHRzPzogQXJyYXk8e1xyXG4gICAgICBwcm92aWRlcklkOiBzdHJpbmc7XHJcbiAgICAgIHByb3ZpZGVyTmFtZTogc3RyaW5nO1xyXG4gICAgICB2ZXJkaWN0OiAndHJ1ZScgfCAnZmFsc2UnIHwgJ3Vua25vd24nO1xyXG4gICAgICBjb25maWRlbmNlOiBudW1iZXI7XHJcbiAgICAgIGV4cGxhbmF0aW9uOiBzdHJpbmc7XHJcbiAgICB9PjtcclxuICAgIGNvbnNlbnN1cz86IHtcclxuICAgICAgdG90YWw6IG51bWJlcjtcclxuICAgICAgYWdyZWVpbmc6IG51bWJlcjtcclxuICAgIH07XHJcbiAgfSk6IHZvaWQge1xyXG4gICAgY29uc3QgY29sb3JzOiBSZWNvcmQ8VmVyZGljdCwgc3RyaW5nPiA9IHtcclxuICAgICAgdHJ1ZTogJyM0Q0FGNTAnLFxyXG4gICAgICBmYWxzZTogJyNmNDQzMzYnLFxyXG4gICAgICB1bmtub3duOiAnI0ZGQzEwNycsXHJcbiAgICAgIG5vX2NsYWltOiAnIzlFOUU5RScsXHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGljb25zOiBSZWNvcmQ8VmVyZGljdCwgc3RyaW5nPiA9IHtcclxuICAgICAgdHJ1ZTogJ+KckycsXHJcbiAgICAgIGZhbHNlOiAn4pyXJyxcclxuICAgICAgdW5rbm93bjogJz8nLFxyXG4gICAgICBub19jbGFpbTogJ+KXiycsXHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGxhYmVsczogUmVjb3JkPFZlcmRpY3QsIHN0cmluZz4gPSB7XHJcbiAgICAgIHRydWU6ICdGYWN0IGNoZWNrIHJlc3VsdDogdmVyaWZpZWQgdHJ1ZScsXHJcbiAgICAgIGZhbHNlOiAnRmFjdCBjaGVjayByZXN1bHQ6IHZlcmlmaWVkIGZhbHNlJyxcclxuICAgICAgdW5rbm93bjogJ0ZhY3QgY2hlY2sgcmVzdWx0OiB1bnZlcmlmaWFibGUnLFxyXG4gICAgICBub19jbGFpbTogJ05vIGZhY3R1YWwgY2xhaW1zIGRldGVjdGVkJyxcclxuICAgIH07XHJcblxyXG4gICAgdGhpcy5zaGFkb3dSb290LmlubmVySFRNTCA9IGBcclxuICAgICAgPHN0eWxlPlxyXG4gICAgICAgICoge1xyXG4gICAgICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5pbmRpY2F0b3Ige1xyXG4gICAgICAgICAgd2lkdGg6IDI4cHg7XHJcbiAgICAgICAgICBoZWlnaHQ6IDI4cHg7XHJcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kOiAke2NvbG9yc1tyZXN1bHQudmVyZGljdF19O1xyXG4gICAgICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgICAgICAgYm94LXNoYWRvdzogMCAycHggOHB4IHJnYmEoMCwgMCwgMCwgMC4yKTtcclxuICAgICAgICAgIHRyYW5zaXRpb246IHRyYW5zZm9ybSAwLjJzIGVhc2UsIGJveC1zaGFkb3cgMC4ycyBlYXNlO1xyXG4gICAgICAgICAgZm9udC1mYW1pbHk6IHN5c3RlbS11aSwgLWFwcGxlLXN5c3RlbSwgc2Fucy1zZXJpZjtcclxuICAgICAgICAgIHVzZXItc2VsZWN0OiBub25lO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmluZGljYXRvcjpob3ZlciB7XHJcbiAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEuMTUpO1xyXG4gICAgICAgICAgYm94LXNoYWRvdzogMCA0cHggMTJweCByZ2JhKDAsIDAsIDAsIDAuMyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuaW5kaWNhdG9yOmFjdGl2ZSB7XHJcbiAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEuMDUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgQGtleWZyYW1lcyBzY2FsZUluIHtcclxuICAgICAgICAgIGZyb20ge1xyXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDApO1xyXG4gICAgICAgICAgICBvcGFjaXR5OiAwO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgdG8ge1xyXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpO1xyXG4gICAgICAgICAgICBvcGFjaXR5OiAxO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmluZGljYXRvci5hbmltYXRlIHtcclxuICAgICAgICAgIGFuaW1hdGlvbjogc2NhbGVJbiAwLjNzIGVhc2Utb3V0O1xyXG4gICAgICAgIH1cclxuICAgICAgPC9zdHlsZT5cclxuICAgICAgPGRpdiBjbGFzcz1cImluZGljYXRvciBhbmltYXRlXCJcclxuICAgICAgICAgICBhcmlhLWxhYmVsPVwiJHtsYWJlbHNbcmVzdWx0LnZlcmRpY3RdfVwiXHJcbiAgICAgICAgICAgdGFiaW5kZXg9XCIwXCJcclxuICAgICAgICAgICByb2xlPVwiYnV0dG9uXCI+XHJcbiAgICAgICAgJHtpY29uc1tyZXN1bHQudmVyZGljdF19XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgYDtcclxuXHJcbiAgICAvLyBBZGQgY2xpY2sgaGFuZGxlciBmb3IgcG9wdXAgKG9ubHkgaWYgbm90IG5vX2NsYWltKVxyXG4gICAgaWYgKHJlc3VsdC52ZXJkaWN0ICE9PSAnbm9fY2xhaW0nKSB7XHJcbiAgICAgIGNvbnN0IGluZGljYXRvciA9IHRoaXMuc2hhZG93Um9vdC5xdWVyeVNlbGVjdG9yKCcuaW5kaWNhdG9yJyk7XHJcbiAgICAgIGluZGljYXRvcj8uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZTogRXZlbnQpID0+IHtcclxuICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpOyAvLyBQcmV2ZW50IGNsaWNrIGZyb20gYnViYmxpbmcgdG8gcG9zdFxyXG4gICAgICAgIHRoaXMuc2hvd1BvcHVwKHJlc3VsdCk7XHJcbiAgICAgIH0pO1xyXG4gICAgICBpbmRpY2F0b3I/LmFkZEV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCAoZTogRXZlbnQpID0+IHtcclxuICAgICAgICBjb25zdCBrZXlFdmVudCA9IGUgYXMgS2V5Ym9hcmRFdmVudDtcclxuICAgICAgICBpZiAoa2V5RXZlbnQua2V5ID09PSAnRW50ZXInIHx8IGtleUV2ZW50LmtleSA9PT0gJyAnKSB7XHJcbiAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpOyAvLyBQcmV2ZW50IGV2ZW50IGZyb20gYnViYmxpbmcgdG8gcG9zdFxyXG4gICAgICAgICAgdGhpcy5zaG93UG9wdXAocmVzdWx0KTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogU2hvdyBkZXRhaWxlZCBleHBsYW5hdGlvbiBwb3B1cFxyXG4gICAqL1xyXG4gIHByaXZhdGUgc2hvd1BvcHVwKHJlc3VsdDoge1xyXG4gICAgdmVyZGljdDogVmVyZGljdDtcclxuICAgIGNvbmZpZGVuY2U6IG51bWJlcjtcclxuICAgIGV4cGxhbmF0aW9uOiBzdHJpbmc7XHJcbiAgICBzb3VyY2VzOiBBcnJheTx7IHRpdGxlOiBzdHJpbmc7IHVybDogc3RyaW5nIH0+O1xyXG4gICAgcHJvdmlkZXJSZXN1bHRzPzogQXJyYXk8e1xyXG4gICAgICBwcm92aWRlcklkOiBzdHJpbmc7XHJcbiAgICAgIHByb3ZpZGVyTmFtZTogc3RyaW5nO1xyXG4gICAgICB2ZXJkaWN0OiAndHJ1ZScgfCAnZmFsc2UnIHwgJ3Vua25vd24nO1xyXG4gICAgICBjb25maWRlbmNlOiBudW1iZXI7XHJcbiAgICAgIGV4cGxhbmF0aW9uOiBzdHJpbmc7XHJcbiAgICB9PjtcclxuICAgIGNvbnNlbnN1cz86IHtcclxuICAgICAgdG90YWw6IG51bWJlcjtcclxuICAgICAgYWdyZWVpbmc6IG51bWJlcjtcclxuICAgIH07XHJcbiAgfSk6IHZvaWQge1xyXG4gICAgLy8gQ2xvc2UgZXhpc3RpbmcgcG9wdXAgaWYgYW55XHJcbiAgICBpZiAodGhpcy5wb3B1cCkge1xyXG4gICAgICB0aGlzLnBvcHVwLmhpZGUoKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBDcmVhdGUgbmV3IHBvcHVwXHJcbiAgICB0aGlzLnBvcHVwID0gbmV3IEZhY3RDaGVja1BvcHVwKHRoaXMuZWxlbWVudCwgcmVzdWx0KTtcclxuICAgIHRoaXMucG9wdXAuc2hvdygpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUmVtb3ZlIGluZGljYXRvciBmcm9tIERPTVxyXG4gICAqL1xyXG4gIHJlbW92ZSgpOiB2b2lkIHtcclxuICAgIGlmICh0aGlzLnBvcHVwKSB7XHJcbiAgICAgIHRoaXMucG9wdXAuaGlkZSgpO1xyXG4gICAgfVxyXG4gICAgdGhpcy5lbGVtZW50LnJlbW92ZSgpO1xyXG4gIH1cclxufVxyXG4iLCIvKipcclxuICogTWFudWFsIENoZWNrIEJ1dHRvbiBDb21wb25lbnRcclxuICogRGlzcGxheWVkIHdoZW4gYXV0by1jaGVjayBpcyBkaXNhYmxlZCwgYWxsb3dzIHVzZXJzIHRvIG1hbnVhbGx5IHRyaWdnZXIgZmFjdC1jaGVja2luZ1xyXG4gKi9cclxuXHJcbmV4cG9ydCBjbGFzcyBDaGVja0J1dHRvbiB7XHJcbiAgcHJpdmF0ZSBlbGVtZW50OiBIVE1MRGl2RWxlbWVudDtcclxuICBwcml2YXRlIHNoYWRvd1Jvb3Q6IFNoYWRvd1Jvb3Q7XHJcbiAgcHJpdmF0ZSBvbkNoZWNrQ2FsbGJhY2s6ICgoKSA9PiB2b2lkKSB8IG51bGwgPSBudWxsO1xyXG4gIHB1YmxpYyByZWFkb25seSBwYXJlbnRFbGVtZW50OiBFbGVtZW50OyAvLyBQdWJsaWMgZm9yIGFjY2VzcyB3aGVuIHJlcGxhY2luZyB3aXRoIGluZGljYXRvclxyXG5cclxuICBjb25zdHJ1Y3RvcihcclxuICAgIHBhcmVudEVsZW1lbnQ6IEVsZW1lbnQsXHJcbiAgICBwcml2YXRlIGVsZW1lbnRJZDogc3RyaW5nXHJcbiAgKSB7XHJcbiAgICB0aGlzLnBhcmVudEVsZW1lbnQgPSBwYXJlbnRFbGVtZW50O1xyXG4gICAgdGhpcy5lbGVtZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XHJcbiAgICB0aGlzLmVsZW1lbnQuaWQgPSBgZmFjdC1jaGVjay1idXR0b24tJHt0aGlzLmVsZW1lbnRJZH1gO1xyXG5cclxuICAgIC8vIFVzZSBTaGFkb3cgRE9NIGZvciBzdHlsZSBpc29sYXRpb25cclxuICAgIHRoaXMuc2hhZG93Um9vdCA9IHRoaXMuZWxlbWVudC5hdHRhY2hTaGFkb3coeyBtb2RlOiAnY2xvc2VkJyB9KTtcclxuXHJcbiAgICAvLyBQb3NpdGlvbiBhYnNvbHV0ZWx5IHNsaWdodGx5IG91dHNpZGUgdG9wLXJpZ2h0IGNvcm5lciBvZiBjYXJkXHJcbiAgICB0aGlzLmVsZW1lbnQuc3R5bGUucG9zaXRpb24gPSAnYWJzb2x1dGUnO1xyXG4gICAgdGhpcy5lbGVtZW50LnN0eWxlLnRvcCA9ICctMTBweCc7XHJcbiAgICB0aGlzLmVsZW1lbnQuc3R5bGUucmlnaHQgPSAnLTEwcHgnO1xyXG4gICAgdGhpcy5lbGVtZW50LnN0eWxlLnpJbmRleCA9ICcyMTQ3NDgzNjQ3JzsgLy8gTWF4aW11bSB6LWluZGV4XHJcblxyXG4gICAgdGhpcy5zaG93QnV0dG9uKCk7XHJcbiAgICB0aGlzLmF0dGFjaFRvUGFyZW50KCk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBBdHRhY2ggYnV0dG9uIHRvIHBhcmVudCBlbGVtZW50XHJcbiAgICovXHJcbiAgcHJpdmF0ZSBhdHRhY2hUb1BhcmVudCgpOiB2b2lkIHtcclxuICAgIC8vIE1ha2UgcGFyZW50IHJlbGF0aXZlbHkgcG9zaXRpb25lZCBpZiBuZWVkZWRcclxuICAgIGNvbnN0IHBhcmVudFN0eWxlID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUodGhpcy5wYXJlbnRFbGVtZW50KTtcclxuICAgIGlmIChwYXJlbnRTdHlsZS5wb3NpdGlvbiA9PT0gJ3N0YXRpYycpIHtcclxuICAgICAgKHRoaXMucGFyZW50RWxlbWVudCBhcyBIVE1MRWxlbWVudCkuc3R5bGUucG9zaXRpb24gPSAncmVsYXRpdmUnO1xyXG4gICAgfVxyXG5cclxuICAgIHRoaXMucGFyZW50RWxlbWVudC5hcHBlbmRDaGlsZCh0aGlzLmVsZW1lbnQpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogU2V0IGNhbGxiYWNrIGZvciB3aGVuIHVzZXIgY2xpY2tzIGNoZWNrIGJ1dHRvblxyXG4gICAqL1xyXG4gIG9uQ2hlY2soY2FsbGJhY2s6ICgpID0+IHZvaWQpOiB2b2lkIHtcclxuICAgIHRoaXMub25DaGVja0NhbGxiYWNrID0gY2FsbGJhY2s7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBTaG93IHRoZSBtYW51YWwgY2hlY2sgYnV0dG9uIChjaXJjdWxhciBiYWRnZSBzdHlsZSBtYXRjaGluZyBpbmRpY2F0b3IpXHJcbiAgICovXHJcbiAgcHJpdmF0ZSBzaG93QnV0dG9uKCk6IHZvaWQge1xyXG4gICAgdGhpcy5zaGFkb3dSb290LmlubmVySFRNTCA9IGBcclxuICAgICAgPHN0eWxlPlxyXG4gICAgICAgICoge1xyXG4gICAgICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5jaGVjay1idXR0b24ge1xyXG4gICAgICAgICAgd2lkdGg6IDI4cHg7XHJcbiAgICAgICAgICBoZWlnaHQ6IDI4cHg7XHJcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kOiAjMTk3NkQyO1xyXG4gICAgICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICAgICAgYm9yZGVyOiBub25lO1xyXG4gICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgICAgICAgYm94LXNoYWRvdzogMCAycHggOHB4IHJnYmEoMCwgMCwgMCwgMC4yKTtcclxuICAgICAgICAgIHRyYW5zaXRpb246IHRyYW5zZm9ybSAwLjJzIGVhc2UsIGJveC1zaGFkb3cgMC4ycyBlYXNlLCBiYWNrZ3JvdW5kIDAuMnMgZWFzZTtcclxuICAgICAgICAgIGZvbnQtZmFtaWx5OiBzeXN0ZW0tdWksIC1hcHBsZS1zeXN0ZW0sIHNhbnMtc2VyaWY7XHJcbiAgICAgICAgICB1c2VyLXNlbGVjdDogbm9uZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5jaGVjay1idXR0b246aG92ZXIge1xyXG4gICAgICAgICAgYmFja2dyb3VuZDogIzE1NjVDMDtcclxuICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMS4xNSk7XHJcbiAgICAgICAgICBib3gtc2hhZG93OiAwIDRweCAxMnB4IHJnYmEoMCwgMCwgMCwgMC4zKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5jaGVjay1idXR0b246YWN0aXZlIHtcclxuICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMS4wNSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBAa2V5ZnJhbWVzIHNjYWxlSW4ge1xyXG4gICAgICAgICAgZnJvbSB7XHJcbiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMCk7XHJcbiAgICAgICAgICAgIG9wYWNpdHk6IDA7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICB0byB7XHJcbiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMSk7XHJcbiAgICAgICAgICAgIG9wYWNpdHk6IDE7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuY2hlY2stYnV0dG9uLmFuaW1hdGUge1xyXG4gICAgICAgICAgYW5pbWF0aW9uOiBzY2FsZUluIDAuM3MgZWFzZS1vdXQ7XHJcbiAgICAgICAgfVxyXG4gICAgICA8L3N0eWxlPlxyXG4gICAgICA8YnV0dG9uIGNsYXNzPVwiY2hlY2stYnV0dG9uIGFuaW1hdGVcIlxyXG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJDbGljayB0byBmYWN0LWNoZWNrIHRoaXMgcG9zdFwiXHJcbiAgICAgICAgICAgICAgdGFiaW5kZXg9XCIwXCJcclxuICAgICAgICAgICAgICByb2xlPVwiYnV0dG9uXCI+XHJcbiAgICAgICAg4pa2XHJcbiAgICAgIDwvYnV0dG9uPlxyXG4gICAgYDtcclxuXHJcbiAgICAvLyBBZGQgY2xpY2sgaGFuZGxlclxyXG4gICAgY29uc3QgYnV0dG9uID0gdGhpcy5zaGFkb3dSb290LnF1ZXJ5U2VsZWN0b3IoJy5jaGVjay1idXR0b24nKTtcclxuICAgIGJ1dHRvbj8uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZTogRXZlbnQpID0+IHtcclxuICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgICAgdGhpcy5oYW5kbGVDbGljaygpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgYnV0dG9uPy5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgKGU6IEV2ZW50KSA9PiB7XHJcbiAgICAgIGNvbnN0IGtleUV2ZW50ID0gZSBhcyBLZXlib2FyZEV2ZW50O1xyXG4gICAgICBpZiAoa2V5RXZlbnQua2V5ID09PSAnRW50ZXInIHx8IGtleUV2ZW50LmtleSA9PT0gJyAnKSB7XHJcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICAgICAgdGhpcy5oYW5kbGVDbGljaygpO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEhhbmRsZSBidXR0b24gY2xpY2tcclxuICAgKi9cclxuICBwcml2YXRlIGhhbmRsZUNsaWNrKCk6IHZvaWQge1xyXG4gICAgLy8gVHJhbnNpdGlvbiB0byBsb2FkaW5nIHN0YXRlXHJcbiAgICB0aGlzLnNob3dMb2FkaW5nKCk7XHJcblxyXG4gICAgLy8gQ2FsbCB0aGUgY2FsbGJhY2tcclxuICAgIGlmICh0aGlzLm9uQ2hlY2tDYWxsYmFjaykge1xyXG4gICAgICB0aGlzLm9uQ2hlY2tDYWxsYmFjaygpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogU2hvdyBsb2FkaW5nIHN0YXRlIChjYWxsZWQgd2hlbiB1c2VyIGNsaWNrcyBidXR0b24pXHJcbiAgICovXHJcbiAgc2hvd0xvYWRpbmcoKTogdm9pZCB7XHJcbiAgICB0aGlzLnNoYWRvd1Jvb3QuaW5uZXJIVE1MID0gYFxyXG4gICAgICA8c3R5bGU+XHJcbiAgICAgICAgKiB7XHJcbiAgICAgICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmluZGljYXRvciB7XHJcbiAgICAgICAgICB3aWR0aDogMjhweDtcclxuICAgICAgICAgIGhlaWdodDogMjhweDtcclxuICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICAgIGJhY2tncm91bmQ6ICNGRkMxMDc7XHJcbiAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgICAgY3Vyc29yOiB3YWl0O1xyXG4gICAgICAgICAgYm94LXNoYWRvdzogMCAycHggOHB4IHJnYmEoMCwgMCwgMCwgMC4yKTtcclxuICAgICAgICAgIGFuaW1hdGlvbjogcHVsc2UgMS41cyBpbmZpbml0ZTtcclxuICAgICAgICAgIGZvbnQtZmFtaWx5OiBzeXN0ZW0tdWksIC1hcHBsZS1zeXN0ZW0sIHNhbnMtc2VyaWY7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBAa2V5ZnJhbWVzIHB1bHNlIHtcclxuICAgICAgICAgIDAlLCAxMDAlIHsgb3BhY2l0eTogMTsgfVxyXG4gICAgICAgICAgNTAlIHsgb3BhY2l0eTogMC42OyB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBAa2V5ZnJhbWVzIHNwaW4ge1xyXG4gICAgICAgICAgZnJvbSB7IHRyYW5zZm9ybTogcm90YXRlKDBkZWcpOyB9XHJcbiAgICAgICAgICB0byB7IHRyYW5zZm9ybTogcm90YXRlKDM2MGRlZyk7IH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5zcGlubmVyIHtcclxuICAgICAgICAgIHdpZHRoOiAxNHB4O1xyXG4gICAgICAgICAgaGVpZ2h0OiAxNHB4O1xyXG4gICAgICAgICAgYm9yZGVyOiAycHggc29saWQgd2hpdGU7XHJcbiAgICAgICAgICBib3JkZXItdG9wLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICAgIGFuaW1hdGlvbjogc3BpbiAxcyBsaW5lYXIgaW5maW5pdGU7XHJcbiAgICAgICAgfVxyXG4gICAgICA8L3N0eWxlPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwiaW5kaWNhdG9yXCIgYXJpYS1sYWJlbD1cIkZhY3QgY2hlY2sgaW4gcHJvZ3Jlc3NcIiByb2xlPVwic3RhdHVzXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInNwaW5uZXJcIj48L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICBgO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUmVtb3ZlIGJ1dHRvbiBmcm9tIERPTVxyXG4gICAqL1xyXG4gIHJlbW92ZSgpOiB2b2lkIHtcclxuICAgIHRoaXMuZWxlbWVudC5yZW1vdmUoKTtcclxuICB9XHJcbn1cclxuIl0sIm5hbWVzIjpbIkZhY3RDaGVja1BvcHVwIiwiYW5jaG9yRWxlbWVudCIsInJlc3VsdCIsImUiLCJyZWN0IiwicG9wdXBXaWR0aCIsInBvcHVwSGVpZ2h0IiwidG9wIiwibGVmdCIsInZpZXdwb3J0V2lkdGgiLCJ2aWV3cG9ydEhlaWdodCIsInZlcmRpY3RDb2xvcnMiLCJ2ZXJkaWN0TGFiZWxzIiwic291cmNlIiwiZG9tYWluIiwicG9wdXBFbGVtZW50IiwiY2xvc2VCdG4iLCJ0YXJnZXQiLCJ1bnNhZmUiLCJ1cmwiLCJ0ZXh0IiwibWF4TGVuZ3RoIiwicHJvdmlkZXJTaG9ydE5hbWVzIiwicHJvdmlkZXIiLCJGYWN0Q2hlY2tJbmRpY2F0b3IiLCJwYXJlbnRFbGVtZW50IiwiZWxlbWVudElkIiwiY29sb3JzIiwiaWNvbnMiLCJsYWJlbHMiLCJpbmRpY2F0b3IiLCJrZXlFdmVudCIsIkNoZWNrQnV0dG9uIiwiY2FsbGJhY2siLCJidXR0b24iXSwibWFwcGluZ3MiOiJBQU9PLE1BQU1BLENBQWUsQ0FLMUIsWUFDVUMsRUFDQUMsRUFpQlIsQ0FsQlEsS0FBQSxjQUFBRCxFQUNBLEtBQUEsT0FBQUMsRUFpWVYsS0FBUSxnQkFBbUJDLEdBQTJCLENBQ2hEQSxFQUFFLE1BQVEsVUFDWixLQUFLLEtBQUEsQ0FFVCxFQW5YRSxLQUFLLFFBQVUsU0FBUyxjQUFjLEtBQUssRUFDM0MsS0FBSyxXQUFhLEtBQUssUUFBUSxhQUFhLENBQUUsS0FBTSxTQUFVLEVBRTlELEtBQUssUUFBUSxNQUFNLFNBQVcsUUFDOUIsS0FBSyxRQUFRLE1BQU0sT0FBUyxhQUU1QixLQUFLLHdCQUEwQixLQUFLLG1CQUFtQixLQUFLLElBQUksRUFFaEUsU0FBUyxLQUFLLFlBQVksS0FBSyxPQUFPLENBQ3hDLENBS0EsTUFBYSxDQUNYLE1BQU1DLEVBQU8sS0FBSyxjQUFjLHNCQUFBLEVBRzFCQyxFQUFhLElBQ2JDLEVBQWMsSUFDcEIsSUFBSUMsRUFBTUgsRUFBSyxPQUFTLEVBQ3BCSSxFQUFPSixFQUFLLE1BQVFDLEVBR3hCLE1BQU1JLEVBQWdCLE9BQU8sV0FDdkJDLEVBQWlCLE9BQU8sWUFHMUJGLEVBQU8sSUFDVEEsRUFBTyxHQUVMQSxFQUFPSCxFQUFhSSxFQUFnQixJQUN0Q0QsRUFBT0MsRUFBZ0JKLEVBQWEsR0FJbENFLEVBQU1ELEVBQWNJLEVBQWlCLElBQ3ZDSCxFQUFNSCxFQUFLLElBQU1FLEVBQWMsRUFDM0JDLEVBQU0sSUFDUkEsRUFBTSxJQUlWLEtBQUssUUFBUSxNQUFNLElBQU0sR0FBR0EsQ0FBRyxLQUMvQixLQUFLLFFBQVEsTUFBTSxLQUFPLEdBQUdDLENBQUksS0FFakMsTUFBTUcsRUFBeUMsQ0FDN0MsS0FBTSxVQUNOLE1BQU8sVUFDUCxRQUFTLFVBQ1QsU0FBVSxTQUFBLEVBR05DLEVBQXlDLENBQzdDLEtBQU0sZ0JBQ04sTUFBTyxpQkFDUCxRQUFTLGVBQ1QsU0FBVSxXQUFBLEVBR1osS0FBSyxXQUFXLFVBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFxQ1JELEVBQWMsS0FBSyxPQUFPLE9BQU8sQ0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQTZEbENBLEVBQWMsS0FBSyxPQUFPLE9BQU8sQ0FBQztBQUFBLG1CQUN2QyxLQUFLLE9BQU8sVUFBVTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBdUhSQyxFQUFjLEtBQUssT0FBTyxPQUFPLENBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQ0FVeEIsS0FBSyxzQkFBc0I7QUFBQTtBQUFBO0FBQUEscUNBR2pDLEtBQUssV0FBVyxLQUFLLE9BQU8sV0FBVyxDQUFDO0FBQUE7QUFBQSxZQUdqRSxLQUFLLE9BQU8sUUFBUSxPQUFTLEVBQ3pCO0FBQUE7QUFBQTtBQUFBLGdCQUdBLEtBQUssT0FBTyxRQUNYLElBQUtDLEdBQVcsQ0FDZixNQUFNQyxFQUFTLEtBQUssY0FBY0QsRUFBTyxHQUFHLEVBQzVDLE1BQU87QUFBQTtBQUFBLDZCQUVJLEtBQUssV0FBV0EsRUFBTyxHQUFHLENBQUMsc0RBQXNELEtBQUssV0FBV0EsRUFBTyxLQUFLLENBQUM7QUFBQSxzQkFDckgsS0FBSyxXQUFXLEtBQUssU0FBU0EsRUFBTyxNQUFPLEVBQUUsQ0FBQyxDQUFDO0FBQUE7QUFBQSwrQ0FFdkIsS0FBSyxXQUFXQyxDQUFNLENBQUM7QUFBQTtBQUFBLGVBR3RELENBQUMsRUFDQSxLQUFLLEVBQUUsQ0FBQztBQUFBO0FBQUEsWUFHVCxFQUNOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFVTixNQUFNQyxFQUFlLEtBQUssV0FBVyxjQUFjLFFBQVEsRUFDM0RBLEdBQUEsTUFBQUEsRUFBYyxpQkFBaUIsUUFBVVosR0FBYSxDQUNwREEsRUFBRSxnQkFBQSxDQUNKLEdBR0EsTUFBTWEsRUFBVyxLQUFLLFdBQVcsY0FBYyxRQUFRLEVBQ3ZEQSxHQUFBLE1BQUFBLEVBQVUsaUJBQWlCLFFBQVMsSUFBTSxLQUFLLFFBRy9DLFdBQVcsSUFBTSxDQUNmLFNBQVMsaUJBQWlCLFFBQVMsS0FBSyx1QkFBdUIsQ0FDakUsRUFBRyxHQUFHLEVBR04sU0FBUyxpQkFBaUIsVUFBVyxLQUFLLGVBQWUsQ0FDM0QsQ0FLQSxNQUFhLENBQ1gsU0FBUyxvQkFBb0IsUUFBUyxLQUFLLHVCQUF1QixFQUNsRSxTQUFTLG9CQUFvQixVQUFXLEtBQUssZUFBZSxFQUM1RCxLQUFLLFFBQVEsT0FBQSxDQUNmLENBS1EsbUJBQW1CLEVBQXFCLENBQzlDLE1BQU1DLEVBQVMsRUFBRSxPQUVmLENBQUMsS0FBSyxRQUFRLFNBQVNBLENBQU0sR0FDN0IsQ0FBQyxLQUFLLGNBQWMsU0FBU0EsQ0FBTSxHQUVuQyxLQUFLLEtBQUEsQ0FFVCxDQWNRLFdBQVdDLEVBQXdCLENBQ3pDLE9BQU9BLEVBQ0osUUFBUSxLQUFNLE9BQU8sRUFDckIsUUFBUSxLQUFNLE1BQU0sRUFDcEIsUUFBUSxLQUFNLE1BQU0sRUFDcEIsUUFBUSxLQUFNLFFBQVEsRUFDdEIsUUFBUSxLQUFNLFFBQVEsQ0FDM0IsQ0FLUSxjQUFjQyxFQUFxQixDQUN6QyxHQUFJLENBRUYsT0FEZSxJQUFJLElBQUlBLENBQUcsRUFDWixTQUFTLFFBQVEsU0FBVSxFQUFFLENBQzdDLE1BQVEsQ0FDTixPQUFPQSxDQUNULENBQ0YsQ0FLUSxTQUFTQyxFQUFjQyxFQUEyQixDQUN4RCxPQUFJRCxFQUFLLFFBQVVDLEVBQWtCRCxFQUM5QkEsRUFBSyxVQUFVLEVBQUdDLEVBQVksQ0FBQyxFQUFJLEtBQzVDLENBS1Esc0JBQStCLENBQ3JDLEdBQUksQ0FBQyxLQUFLLE9BQU8saUJBQW1CLEtBQUssT0FBTyxnQkFBZ0IsU0FBVyxFQUN6RSxNQUFPLEdBQUcsS0FBSyxPQUFPLFVBQVUsY0FJbEMsTUFBTUMsRUFBNkMsQ0FDakQsT0FBUSxTQUNSLFVBQVcsWUFDWCxXQUFZLFlBQUEsRUFVZCxNQUFPO0FBQUE7QUFBQSxVQVBnQixLQUFLLE9BQU8sZ0JBQ2hDLElBQUtDLEdBRUcsbUVBRFdELEVBQW1CQyxFQUFTLFVBQVUsR0FBS0EsRUFBUyxZQUNhLFlBQVlBLEVBQVMsVUFBVSxVQUNuSCxFQUNBLEtBQUssRUFBRSxDQUlVO0FBQUE7QUFBQSx5Q0FFaUIsS0FBSyxPQUFPLFVBQVU7QUFBQSxLQUU3RCxDQUNGLENDMWNPLE1BQU1DLENBQW1CLENBSzlCLFlBQ1VDLEVBQ0FDLEVBQ1IsQ0FGUSxLQUFBLGNBQUFELEVBQ0EsS0FBQSxVQUFBQyxFQUpWLEtBQVEsTUFBK0IsS0FNckMsS0FBSyxRQUFVLFNBQVMsY0FBYyxLQUFLLEVBQzNDLEtBQUssUUFBUSxHQUFLLHdCQUF3QixLQUFLLFNBQVMsR0FHeEQsS0FBSyxXQUFhLEtBQUssUUFBUSxhQUFhLENBQUUsS0FBTSxTQUFVLEVBRzlELEtBQUssUUFBUSxNQUFNLFNBQVcsV0FDOUIsS0FBSyxRQUFRLE1BQU0sSUFBTSxRQUN6QixLQUFLLFFBQVEsTUFBTSxNQUFRLFFBQzNCLEtBQUssUUFBUSxNQUFNLE9BQVMsYUFFNUIsS0FBSyxZQUFBLEVBQ0wsS0FBSyxlQUFBLENBQ1AsQ0FLUSxnQkFBdUIsQ0FFVCxPQUFPLGlCQUFpQixLQUFLLGFBQWEsRUFDOUMsV0FBYSxXQUMxQixLQUFLLGNBQThCLE1BQU0sU0FBVyxZQUd2RCxLQUFLLGNBQWMsWUFBWSxLQUFLLE9BQU8sQ0FDN0MsQ0FLQSxhQUFvQixDQUNsQixLQUFLLFdBQVcsVUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FnRDlCLENBS0EsV0FBV3hCLEVBZ0JGLENBQ1AsTUFBTXlCLEVBQWtDLENBQ3RDLEtBQU0sVUFDTixNQUFPLFVBQ1AsUUFBUyxVQUNULFNBQVUsU0FBQSxFQUdOQyxFQUFpQyxDQUNyQyxLQUFNLElBQ04sTUFBTyxJQUNQLFFBQVMsSUFDVCxTQUFVLEdBQUEsRUFHTkMsRUFBa0MsQ0FDdEMsS0FBTSxtQ0FDTixNQUFPLG9DQUNQLFFBQVMsa0NBQ1QsU0FBVSw0QkFBQSxFQTREWixHQXpEQSxLQUFLLFdBQVcsVUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQVVSRixFQUFPekIsRUFBTyxPQUFPLENBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBdUNyQjJCLEVBQU8zQixFQUFPLE9BQU8sQ0FBQztBQUFBO0FBQUE7QUFBQSxVQUdyQzBCLEVBQU0xQixFQUFPLE9BQU8sQ0FBQztBQUFBO0FBQUEsTUFLdkJBLEVBQU8sVUFBWSxXQUFZLENBQ2pDLE1BQU00QixFQUFZLEtBQUssV0FBVyxjQUFjLFlBQVksRUFDNURBLEdBQUEsTUFBQUEsRUFBVyxpQkFBaUIsUUFBVTNCLEdBQWEsQ0FDakRBLEVBQUUsZ0JBQUEsRUFDRixLQUFLLFVBQVVELENBQU0sQ0FDdkIsR0FDQTRCLEdBQUEsTUFBQUEsRUFBVyxpQkFBaUIsVUFBWTNCLEdBQWEsQ0FDbkQsTUFBTTRCLEVBQVc1QixHQUNiNEIsRUFBUyxNQUFRLFNBQVdBLEVBQVMsTUFBUSxPQUMvQzVCLEVBQUUsZUFBQSxFQUNGQSxFQUFFLGdCQUFBLEVBQ0YsS0FBSyxVQUFVRCxDQUFNLEVBRXpCLEVBQ0YsQ0FDRixDQUtRLFVBQVVBLEVBZ0JULENBRUgsS0FBSyxPQUNQLEtBQUssTUFBTSxLQUFBLEVBSWIsS0FBSyxNQUFRLElBQUlGLEVBQWUsS0FBSyxRQUFTRSxDQUFNLEVBQ3BELEtBQUssTUFBTSxLQUFBLENBQ2IsQ0FLQSxRQUFlLENBQ1QsS0FBSyxPQUNQLEtBQUssTUFBTSxLQUFBLEVBRWIsS0FBSyxRQUFRLE9BQUEsQ0FDZixDQUNGLENDelBPLE1BQU04QixDQUFZLENBTXZCLFlBQ0VQLEVBQ1FDLEVBQ1IsQ0FEUSxLQUFBLFVBQUFBLEVBTFYsS0FBUSxnQkFBdUMsS0FPN0MsS0FBSyxjQUFnQkQsRUFDckIsS0FBSyxRQUFVLFNBQVMsY0FBYyxLQUFLLEVBQzNDLEtBQUssUUFBUSxHQUFLLHFCQUFxQixLQUFLLFNBQVMsR0FHckQsS0FBSyxXQUFhLEtBQUssUUFBUSxhQUFhLENBQUUsS0FBTSxTQUFVLEVBRzlELEtBQUssUUFBUSxNQUFNLFNBQVcsV0FDOUIsS0FBSyxRQUFRLE1BQU0sSUFBTSxRQUN6QixLQUFLLFFBQVEsTUFBTSxNQUFRLFFBQzNCLEtBQUssUUFBUSxNQUFNLE9BQVMsYUFFNUIsS0FBSyxXQUFBLEVBQ0wsS0FBSyxlQUFBLENBQ1AsQ0FLUSxnQkFBdUIsQ0FFVCxPQUFPLGlCQUFpQixLQUFLLGFBQWEsRUFDOUMsV0FBYSxXQUMxQixLQUFLLGNBQThCLE1BQU0sU0FBVyxZQUd2RCxLQUFLLGNBQWMsWUFBWSxLQUFLLE9BQU8sQ0FDN0MsQ0FLQSxRQUFRUSxFQUE0QixDQUNsQyxLQUFLLGdCQUFrQkEsQ0FDekIsQ0FLUSxZQUFtQixDQUN6QixLQUFLLFdBQVcsVUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUEyRDVCLE1BQU1DLEVBQVMsS0FBSyxXQUFXLGNBQWMsZUFBZSxFQUM1REEsR0FBQSxNQUFBQSxFQUFRLGlCQUFpQixRQUFVL0IsR0FBYSxDQUM5Q0EsRUFBRSxnQkFBQSxFQUNGLEtBQUssWUFBQSxDQUNQLEdBRUErQixHQUFBLE1BQUFBLEVBQVEsaUJBQWlCLFVBQVkvQixHQUFhLENBQ2hELE1BQU00QixFQUFXNUIsR0FDYjRCLEVBQVMsTUFBUSxTQUFXQSxFQUFTLE1BQVEsT0FDL0M1QixFQUFFLGVBQUEsRUFDRkEsRUFBRSxnQkFBQSxFQUNGLEtBQUssWUFBQSxFQUVULEVBQ0YsQ0FLUSxhQUFvQixDQUUxQixLQUFLLFlBQUEsRUFHRCxLQUFLLGlCQUNQLEtBQUssZ0JBQUEsQ0FFVCxDQUtBLGFBQW9CLENBQ2xCLEtBQUssV0FBVyxVQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBMkM5QixDQUtBLFFBQWUsQ0FDYixLQUFLLFFBQVEsT0FBQSxDQUNmLENBQ0YifQ==
